# Релизная (не debug) сборка APK

Релиз подписывается **вашим** ключом. Ключ создаёте только вы и никому не отдаёте: потеряете его, и обновить приложение будет нельзя.

## 1. Создайте ключ (один раз, на своём компьютере; нужен JDK)
```
keytool -genkeypair -v -keystore release.keystore -alias dumplinch -keyalg RSA -keysize 2048 -validity 10000
```
Когда спросит пароли, задайте **один и тот же пароль** для хранилища и для ключа (так требует Godot при экспорте из консоли).

## 2. Добавьте секреты в GitHub (Settings -> Secrets and variables -> Actions)
- `ANDROID_KEYSTORE_BASE64`: вывод `base64 -w0 release.keystore` (на macOS: `base64 -i release.keystore`)
- `ANDROID_KEYSTORE_ALIAS`: `dumplinch`
- `ANDROID_KEYSTORE_PASSWORD`: ваш пароль

## 3. Запустите сборку
Actions -> «Build Android APK» -> Run workflow. Готовый файл появится в артефакте **DumplinchEggHunt-RELEASE-apk**
(без секретов собирается только debug-версия). Пароль и keystore нигде не попадают в репозиторий.

## Локально
Godot -> Project -> Export -> пресет **Android Release** -> укажите keystore, alias и пароль -> снимите «Export With Debug» -> Export Project.
Пресет уже настроен: ARM64, `org.dumplinch.egghunt`, версия 0.3.0 (код 3), без служебных файлов.

## Что проверить перед публикацией
- Для Google Play нужен AAB (в Godot 4.3: включить Gradle-сборку и формат AAB); этот APK подходит для установки напрямую.
- Админ-пароль проверяется в самом приложении (см. README): в публичном релизе это можно обойти.
