extends Node3D
## Опасная зона на арене босса: сначала предупреждение (жёлтая пульсация), затем урон (красная).

var radius = 4.0
var dmg = 10.0
var warn = 1.6
var active_t = 4.0
var _t = 0.0
var _tick = 0.0
var mat
var ring_mat


func _ready():
    var disc = MeshInstance3D.new()
    var cm = CylinderMesh.new()
    cm.top_radius = 1.0
    cm.bottom_radius = 1.0
    cm.height = 0.05
    cm.radial_segments = 28
    mat = StandardMaterial3D.new()
    mat.albedo_color = Color(1, 0.8, 0.1, 0.25)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    cm.material = mat
    disc.mesh = cm
    disc.scale = Vector3(radius, 1, radius)
    add_child(disc)
    var ring = MeshInstance3D.new()
    var tm = TorusMesh.new()
    tm.inner_radius = 0.96
    tm.outer_radius = 1.0
    tm.rings = 32
    tm.ring_segments = 4
    ring_mat = StandardMaterial3D.new()
    ring_mat.albedo_color = Color(1, 0.9, 0.2)
    ring_mat.emission_enabled = true
    ring_mat.emission = Color(1, 0.9, 0.2)
    ring_mat.emission_energy_multiplier = 2.0
    ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ring.mesh = tm
    ring.material_override = ring_mat
    ring.scale = Vector3(radius, 1, radius)
    add_child(ring)


func _process(delta):
    _t += delta
    if _t < warn:
        mat.albedo_color = Color(1, 0.8, 0.1, 0.18 + 0.14 * sin(_t * 14.0))
    elif _t < warn + active_t:
        mat.albedo_color = Color(1, 0.15, 0.05, 0.5)
        ring_mat.albedo_color = Color(1, 0.2, 0.1)
        ring_mat.emission = Color(1, 0.2, 0.1)
        _tick -= delta
        var pl = GameState.player_node
        if _tick <= 0.0 and pl != null and not pl.dead:
            _tick = 0.5
            var d = Vector2(pl.global_position.x - global_position.x, pl.global_position.z - global_position.z).length()
            if d < radius and pl.global_position.y < 1.4:
                pl.take_damage(dmg, global_position)
    else:
        mat.albedo_color.a = maxf(0.0, mat.albedo_color.a - delta * 2.0)
        if mat.albedo_color.a <= 0.0:
            queue_free()
