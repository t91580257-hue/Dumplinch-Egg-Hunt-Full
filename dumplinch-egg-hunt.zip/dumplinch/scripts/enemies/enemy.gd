extends CharacterBody3D
## Враг региона. Три вида атак: ближний удар, рывок и дальний выстрел (все с заметным предупреждением «!»).
## Реагирует на удары: отбрасывание, сплющивание, оглушение от сильных ударов.

const Fx = preload("res://scripts/vfx/fx.gd")
const Projectile = preload("res://scripts/enemies/projectile.gd")
signal died(enemy)

var region = 0
var home = Vector3.ZERO
var kind = "melee"
var max_hp = 50.0
var hp = 50.0
var dmg = 6.0
var dead = false
var hit_radius = 0.7
var state = "idle"
var st_t = 0.0
var stagger_imm = 0.0
var wander_t = 0.0
var wander_dir = Vector3.ZERO
var speed = 3.5
var dash_dir = Vector3.FORWARD
var dash_hit = false
var mesh_root
var mat
var bar_fill
var bar_bg
var mark
var flash = 0.0
var _far = false
var _far_t = 0.0


func setup(r, h):
    region = r
    home = h
    max_hp = 45.0 * (1.0 + 1.1 * r)
    hp = max_hp
    dmg = 6.0 + 5.0 * r
    speed = 3.4 + 0.3 * r
    position = h + Vector3(0, 1.0, 0)
    var roll = randf()
    if roll < 0.25:
        kind = "lunge"
    elif roll < 0.42 and r >= 1:
        kind = "ranged"


func _ready():
    add_to_group("enemies")
    var cs = CollisionShape3D.new()
    var sh = SphereShape3D.new()
    sh.radius = 0.6
    cs.shape = sh
    cs.position = Vector3(0, 0.6, 0)
    add_child(cs)
    mesh_root = Node3D.new()
    add_child(mesh_root)
    var cols = [Color("5acb58"), Color("e8f4ff"), Color("ff6a2a"), Color("e8f0ff"), Color("7a40c0")]
    var c = cols[region]
    mat = StandardMaterial3D.new()
    mat.albedo_color = c
    mat.roughness = 0.5
    mat.emission_enabled = true
    mat.emission = Color(1, 0.2, 0.2)
    mat.emission_energy_multiplier = 0.0
    var body = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sm.radius = 0.6
    sm.height = 1.2
    sm.radial_segments = 16
    sm.rings = 8
    body.mesh = sm
    body.material_override = mat
    body.position = Vector3(0, 0.6, 0)
    body.scale = Vector3(1.0, 0.85 if region == 0 else 1.0, 1.0)
    mesh_root.add_child(body)
    if region == 1:
        var head = MeshInstance3D.new()
        var hm = SphereMesh.new()
        hm.radius = 0.38
        hm.height = 0.76
        head.mesh = hm
        head.material_override = mat
        head.position = Vector3(0, 1.4, 0)
        mesh_root.add_child(head)
    if region == 2 or region == 4:
        for s in [-1, 1]:
            var horn = MeshInstance3D.new()
            var cm = CylinderMesh.new()
            cm.top_radius = 0.0
            cm.bottom_radius = 0.1
            cm.height = 0.4
            horn.mesh = cm
            horn.material_override = mat
            horn.position = Vector3(0.3 * s, 1.15, 0)
            horn.rotation.z = -0.4 * s
            mesh_root.add_child(horn)
    if kind == "lunge":
        for s in [-1, 1]:
            var sp = MeshInstance3D.new()
            var spm = CylinderMesh.new()
            spm.top_radius = 0.0
            spm.bottom_radius = 0.09
            spm.height = 0.35
            sp.mesh = spm
            sp.material_override = mat
            sp.position = Vector3(0.45 * s, 0.7, 0.25)
            sp.rotation = Vector3(1.2, 0, -0.4 * s)
            mesh_root.add_child(sp)
    var eye_col = Color("151515")
    if kind == "lunge":
        eye_col = Color("ff3030")
    elif kind == "ranged":
        eye_col = Color("40a0ff")
    elif region >= 2:
        eye_col = Color("ffee66")
    var eye_mat = StandardMaterial3D.new()
    eye_mat.albedo_color = eye_col
    eye_mat.emission_enabled = (kind != "melee" or region >= 2)
    eye_mat.emission = eye_col
    eye_mat.emission_energy_multiplier = 2.0
    for s in [-1, 1]:
        var e = MeshInstance3D.new()
        var em = SphereMesh.new()
        em.radius = 0.08
        em.height = 0.16
        e.mesh = em
        e.material_override = eye_mat
        e.position = Vector3(0.2 * s, 0.75, 0.5)
        mesh_root.add_child(e)
    bar_bg = MeshInstance3D.new()
    var q = QuadMesh.new()
    q.size = Vector2(1.2, 0.14)
    bar_bg.mesh = q
    var bgm = StandardMaterial3D.new()
    bgm.albedo_color = Color(0, 0, 0, 0.7)
    bgm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    bgm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    bgm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    bar_bg.material_override = bgm
    bar_bg.position = Vector3(0, 1.7, 0)
    add_child(bar_bg)
    bar_fill = MeshInstance3D.new()
    var q2 = QuadMesh.new()
    q2.size = Vector2(1.16, 0.1)
    bar_fill.mesh = q2
    var fm = StandardMaterial3D.new()
    fm.albedo_color = Color("ff4a4a")
    fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    fm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    bar_fill.material_override = fm
    bar_fill.position = Vector3(0, 1.7, 0.01)
    add_child(bar_fill)
    bar_fill.visible = false
    bar_bg.visible = false
    mark = Label3D.new()
    mark.text = "!"
    mark.font_size = 96
    mark.pixel_size = 0.01
    mark.modulate = Color("ff3030")
    mark.outline_size = 14
    mark.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    mark.no_depth_test = true
    mark.position = Vector3(0, 2.3, 0)
    mark.visible = false
    add_child(mark)


func hit(amount, crit, from, kb = 1.0):
    if dead:
        return
    hp -= amount
    flash = 0.2
    var dir = global_position - from
    dir.y = 0
    if dir.length() > 0.01:
        velocity += dir.normalized() * (5.0 * kb)
    Fx.damage_number(get_parent(), global_position + Vector3(0, 2.0, 0), str(int(amount)) + ("!" if crit else ""), Color("ffd24a") if crit else Color.WHITE, crit)
    Fx.burst(get_parent(), global_position + Vector3(0, 0.8, 0), Color("ffe9a0") if not crit else Color("ffb030"), 8 + int(4 * kb), 3.5, 0.35)
    AudioManager.play_sfx("crit" if crit else "hit", randf_range(0.9, 1.1))
    bar_fill.visible = true
    bar_bg.visible = true
    var ratio = clampf(hp / max_hp, 0.0, 1.0)
    bar_fill.scale.x = maxf(ratio, 0.001)
    bar_fill.position.x = -0.58 * (1.0 - ratio)
    mesh_root.scale = Vector3(1.3, 0.7, 1.3)
    create_tween().tween_property(mesh_root, "scale", Vector3.ONE, 0.18)
    # сильный удар или критический срывает атаку (но не бесконечно: после оглушения короткая неуязвимость к оглушению)
    if (kb >= 1.4 or crit) and stagger_imm <= 0.0 and state != "stagger" and state != "lunging" and hp > 0.0:
        state = "stagger"
        st_t = 0.4
        stagger_imm = 1.4
        mark.visible = false
    elif state == "idle":
        state = "chase"
    if hp <= 0.0:
        _die()


func _die():
    dead = true
    remove_from_group("enemies")
    mark.visible = false
    GameState.record_kill()
    var coins = GameState.gain_coins(int(8 * (1 + region * 1.5)))
    GameState.gain_xp(int(12 * (1 + region)))
    if randf() < 0.05:
        var eid = GameData.REGIONS[region].eggs[0]
        GameState.add_egg(eid, 1)
        GameState.message.emit("Враг уронил яйцо: " + GameData.egg(eid).name)
    Fx.damage_number(get_parent(), global_position + Vector3(0, 2.4, 0), "+%d" % coins, Color("ffd24a"))
    Fx.burst(get_parent(), global_position + Vector3(0, 0.8, 0), Color("ffd24a"), 14, 5.0, 0.6)
    AudioManager.play_sfx("coin")
    died.emit(self)
    var tw = create_tween()
    tw.set_parallel(true)
    tw.tween_property(mesh_root, "scale", Vector3.ZERO, 0.4)
    tw.tween_property(mesh_root, "rotation:z", 5.0, 0.4)
    tw.tween_property(mesh_root, "position:y", 1.2, 0.4)
    tw.chain().tween_callback(queue_free)


func _telegraph(on):
    mark.visible = on


func _physics_process(delta):
    if dead:
        return
    var pl = GameState.player_node
    if pl == null:
        return
    _far_t -= delta
    if _far_t <= 0.0:
        _far_t = 0.5
        _far = pl.global_position.distance_to(global_position) > 110.0
    if _far:
        return
    if not is_on_floor():
        velocity.y -= 25.0 * delta
    flash = maxf(0.0, flash - delta)
    stagger_imm = maxf(0.0, stagger_imm - delta)
    mat.emission_energy_multiplier = flash * 6.0
    var to = pl.global_position - global_position
    to.y = 0
    var dist = to.length()
    var want = Vector3.ZERO
    var active = not pl.dead and not GameState.in_menu
    match state:
        "idle":
            wander_t -= delta
            if wander_t <= 0.0:
                wander_t = randf_range(1.5, 4.0)
                wander_dir = Vector3(randf_range(-1, 1), 0, randf_range(-1, 1)).normalized() if randf() < 0.6 else Vector3.ZERO
            var back = home - global_position
            back.y = 0
            want = (back.normalized() if back.length() > 30.0 else wander_dir) * speed * 0.4
            if hp < max_hp:
                hp = minf(max_hp, hp + max_hp * 0.05 * delta)
            if dist < 14.0 and active:
                state = "chase"
        "chase":
            var hd = global_position - home
            hd.y = 0
            want = to.normalized() * speed
            if kind == "ranged":
                if dist < 6.0:
                    want = -to.normalized() * speed * 0.9
                elif dist < 14.0:
                    want = Vector3.ZERO
                    state = "shoot_wind"
                    st_t = 0.9
                    _telegraph(true)
            elif kind == "lunge" and dist < 7.0 and dist > 2.6:
                state = "lunge_wind"
                st_t = 0.75
                _telegraph(true)
            if dist < 1.9 and state == "chase":
                state = "windup"
                st_t = 0.45
                _telegraph(true)
            if state == "chase" and (dist > 32.0 or not active or hd.length() > 55.0):
                state = "idle"
        "windup":
            st_t -= delta
            mesh_root.scale = Vector3.ONE * (1.0 + 0.2 * sin(st_t * 30.0))
            if st_t <= 0.0:
                mesh_root.scale = Vector3.ONE
                _telegraph(false)
                if dist < 2.5:
                    pl.take_damage(dmg, global_position)
                state = "recover"
                st_t = 1.0
        "lunge_wind":
            st_t -= delta
            mesh_root.scale = Vector3(1.0 + 0.1 * sin(st_t * 40.0), 1.0 - 0.15 * (0.75 - st_t), 1.0 + 0.1 * sin(st_t * 40.0))
            mat.emission_energy_multiplier = 1.5
            if st_t > 0.2:
                dash_dir = to.normalized()
            if st_t <= 0.0:
                mesh_root.scale = Vector3.ONE
                _telegraph(false)
                state = "lunging"
                st_t = 0.35
                dash_hit = false
                AudioManager.play_sfx("whoosh", 1.0)
        "lunging":
            st_t -= delta
            want = dash_dir * 14.0
            if not dash_hit and dist < 1.7:
                dash_hit = true
                pl.take_damage(dmg * 1.1, global_position)
            if st_t <= 0.0:
                state = "recover"
                st_t = 1.2
        "shoot_wind":
            st_t -= delta
            mat.emission_energy_multiplier = 1.2 + sin(st_t * 20.0)
            if st_t <= 0.0:
                _telegraph(false)
                var pj = Projectile.new()
                pj.dir = (pl.global_position + Vector3(0, 0.9, 0) - (global_position + Vector3(0, 1.0, 0))).normalized()
                pj.speed = 9.0
                pj.dmg = dmg * 0.8
                pj.color = Color("40a0ff")
                get_parent().add_child(pj)
                pj.global_position = global_position + Vector3(0, 1.0, 0)
                AudioManager.play_sfx("special", 1.4)
                state = "recover"
                st_t = 1.6
        "stagger":
            st_t -= delta
            if st_t <= 0.0:
                state = "chase"
        "recover":
            st_t -= delta
            if st_t <= 0.0:
                state = "chase"
    velocity.x = lerpf(velocity.x, want.x, 1.0 - exp(-8.0 * delta))
    velocity.z = lerpf(velocity.z, want.z, 1.0 - exp(-8.0 * delta))
    if Vector2(velocity.x, velocity.z).length() > 0.3 and state != "stagger":
        mesh_root.rotation.y = lerp_angle(mesh_root.rotation.y, atan2(velocity.x, velocity.z), 1.0 - exp(-10.0 * delta))
    move_and_slide()
