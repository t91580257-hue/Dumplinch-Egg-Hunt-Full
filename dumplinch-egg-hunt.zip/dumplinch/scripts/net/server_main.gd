extends Node
## Выделенный сервер без графики (для VPS):
##   godot --headless --path . scenes/server.tscn -- --port 7777
## Принимает игроков, ведёт список, пересылает позиции, чат и объявления администраторов.


func _ready():
    var port = NetworkManager.DEFAULT_PORT
    var args = OS.get_cmdline_user_args()
    for i in args.size():
        if args[i] == "--port" and i + 1 < args.size():
            port = int(args[i + 1])
    if NetworkManager.host(port, true):
        print("DUMPLINCH сервер запущен на порту ", port)
    else:
        print("Не удалось запустить сервер на порту ", port)
        get_tree().quit(1)
    NetworkManager.chat_received.connect(func(n, t, a): print("[чат] %s: %s" % [n, t]))
    NetworkManager.roster_changed.connect(func(): print("Игроков в сети: ", NetworkManager.roster.size()))
