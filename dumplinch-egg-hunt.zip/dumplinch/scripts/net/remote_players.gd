extends Node3D
## Другие игроки: простые модели Dumplinch с ником, плавное движение между пакетами.

const ProcTex = preload("res://scripts/util/proc_tex.gd")
var avatars = {}


func _ready():
    NetworkManager.remote_state.connect(_on_state)
    NetworkManager.peer_left.connect(_on_left)


func _mat(c, rough = 0.8):
    var m = StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.rim_enabled = true
    m.rim = 0.4
    return m


func _part(parent, mesh, mat, pos, scl = Vector3.ONE):
    var mi = MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = mat
    mi.position = pos
    mi.scale = scl
    parent.add_child(mi)
    return mi


func _sph(r):
    var s = SphereMesh.new()
    s.radius = r
    s.height = r * 2.0
    s.radial_segments = 14
    s.rings = 7
    return s


func _make(nick, hat_key):
    var root = Node3D.new()
    var vis = Node3D.new()
    vis.name = "Vis"
    root.add_child(vis)
    var body = Node3D.new()
    body.name = "Body"
    body.position = Vector3(0, 0.62, 0)
    vis.add_child(body)
    var bm = _mat(Color("f6e3c2"), 0.85)
    bm.albedo_texture = ProcTex.noise_texture(Color("ebd3a8"), Color("fff1d8"), 64, 0.09, 7)
    _part(body, _sph(0.5), bm, Vector3.ZERO, Vector3(1.3, 0.9, 1.05))
    for i in 7:
        var x = lerpf(-0.5, 0.5, i / 6.0)
        _part(body, _sph(0.09), _mat(Color("e2c898")), Vector3(x, 0.45 * sqrt(maxf(0.0, 1.0 - pow(x / 0.65, 2.0))), 0), Vector3(1, 1.5, 1.2))
    for s in [-1, 1]:
        _part(body, _sph(0.07), _mat(Color("141414"), 0.2), Vector3(0.2 * s, 0.1, 0.47), Vector3(1, 1.3, 0.7))
        _part(vis, _sph(0.13), _mat(Color("6b4a2f")), Vector3(0.25 * s, 0.1, 0.1), Vector3(1, 0.6, 1.4))
    var cone = CylinderMesh.new()
    cone.top_radius = 0.0
    cone.bottom_radius = 0.3
    cone.height = 0.45
    var hc = GameData.COSMETICS.get(hat_key, GameData.COSMETICS["default"]).color
    var hat = _part(body, cone, _mat(hc), Vector3(0, 0.68, -0.02))
    hat.rotation.x = -0.12
    var l = Label3D.new()
    l.text = nick
    l.font_size = 56
    l.pixel_size = 0.008
    l.outline_size = 12
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.no_depth_test = true
    l.position = Vector3(0, 2.1, 0)
    root.add_child(l)
    return {"node": root, "vis": vis, "body": body, "label": l, "pos": Vector3.ZERO, "yaw": 0.0, "anim": "idle", "hat": hat_key, "init": false, "t": 0.0}


func _on_state(id, pos, yaw, anim, hat, nick):
    if id == multiplayer.get_unique_id():
        return
    if not avatars.has(id):
        var a = _make(nick, hat)
        add_child(a.node)
        avatars[id] = a
    var a2 = avatars[id]
    a2.pos = pos
    a2.yaw = yaw
    a2.anim = anim
    if not a2.init:
        a2.init = true
        a2.node.global_position = pos


func _on_left(id):
    if avatars.has(id):
        avatars[id].node.queue_free()
        avatars.erase(id)


func _process(delta):
    for id in avatars:
        var a = avatars[id]
        a.t += delta
        var node = a.node
        node.global_position = node.global_position.lerp(a.pos, 1.0 - exp(-12.0 * delta))
        a.vis.rotation.y = lerp_angle(a.vis.rotation.y, a.yaw, 1.0 - exp(-12.0 * delta))
        var bob = 0.0
        match a.anim:
            "walk": bob = absf(sin(a.t * 8.0)) * 0.08
            "run": bob = absf(sin(a.t * 12.0)) * 0.14
            "sprint": bob = absf(sin(a.t * 16.0)) * 0.18
            "dance", "victory": bob = absf(sin(a.t * 7.0)) * 0.25
        a.body.position.y = 0.62 + bob
