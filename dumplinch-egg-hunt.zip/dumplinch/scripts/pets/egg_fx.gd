extends Node3D
## Особые визуальные эффекты уникальных яиц (кольца, осколки, пламя, молнии, часы и т.д.).

var kind = ""
var accent = Color.WHITE
var base = Color.WHITE
var parts = []
var hands = []
var mesh_node
var shell
var t = 0.0


func _m(c, e = 2.0, a = 1.0):
    var m = StandardMaterial3D.new()
    m.albedo_color = Color(c.r, c.g, c.b, a)
    m.emission_enabled = true
    m.emission = c
    m.emission_energy_multiplier = e
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    if a < 1.0:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m


func _ring(r, c, tilt):
    var mi = MeshInstance3D.new()
    var tm = TorusMesh.new()
    tm.inner_radius = r - 0.03
    tm.outer_radius = r + 0.03
    tm.rings = 28
    tm.ring_segments = 6
    mi.mesh = tm
    mi.material_override = _m(c)
    mi.rotation = tilt
    add_child(mi)
    return mi


func _orb(r, c, e = 2.5):
    var mi = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sm.radius = r
    sm.height = r * 2.0
    sm.radial_segments = 8
    sm.rings = 4
    mi.mesh = sm
    mi.material_override = _m(c, e)
    add_child(mi)
    return mi


func _cone(r, h, c):
    var mi = MeshInstance3D.new()
    var cm = CylinderMesh.new()
    cm.top_radius = 0.0
    cm.bottom_radius = r
    cm.height = h
    cm.radial_segments = 5
    mi.mesh = cm
    mi.material_override = _m(c, 2.0)
    add_child(mi)
    return mi


func _particles(c, amount, dir, speed):
    var p = CPUParticles3D.new()
    p.amount = maxi(4, int(amount * GameState.particle_scale()))
    p.lifetime = 1.4
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    p.emission_sphere_radius = 0.55
    p.direction = dir
    p.spread = 25.0
    p.initial_velocity_min = speed * 0.5
    p.initial_velocity_max = speed
    p.gravity = Vector3.ZERO
    var sm = SphereMesh.new()
    sm.radius = 0.05
    sm.height = 0.1
    sm.radial_segments = 6
    sm.rings = 3
    sm.material = _m(c, 3.0)
    p.mesh = sm
    add_child(p)


func _ready():
    mesh_node = get_parent().get_node("Mesh")
    match kind:
        "orbit_rings":
            for i in 2:
                parts.append({"n": _ring(0.85 + i * 0.15, accent, Vector3(0.6 * i, 0, 0.9 * i)), "s": 1.0 + i * 0.7})
        "blackhole":
            parts.append({"n": _ring(0.95, accent, Vector3(1.25, 0, 0)), "s": 2.0})
            parts.append({"n": _ring(0.72, Color("ff9a3a"), Vector3(1.25, 0, 0)), "s": -3.0})
        "ghost":
            var gm = mesh_node.material_override
            gm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
            gm.albedo_color = Color(1, 1, 1, 0.55)
            _particles(Color("c8f0ff"), 14, Vector3.UP, 0.4)
        "flames":
            _particles(Color("ff8a2a"), 26, Vector3.UP, 1.4)
            _particles(Color("ffe060"), 12, Vector3.UP, 1.0)
        "shards":
            for i in 6:
                parts.append({"n": _cone(0.12, 0.45, accent), "a": i * TAU / 6.0, "r": 0.95, "h": 0.1 * i - 0.2, "w": 0.8})
        "clock":
            _ring(0.9, accent, Vector3(PI / 2.0, 0, 0))
            for i in 2:
                var pivot = Node3D.new()
                add_child(pivot)
                var hand = MeshInstance3D.new()
                var bm = BoxMesh.new()
                bm.size = Vector3(0.04, 0.04, 0.4 + 0.2 * i)
                hand.mesh = bm
                hand.material_override = _m(accent)
                hand.position = Vector3(0, 0, (0.2 + 0.1 * i))
                pivot.add_child(hand)
                pivot.position = Vector3(0, 0, 0.0)
                pivot.rotation = Vector3(0, 0, 0)
                hands.append({"n": pivot, "w": 1.0 + i * 6.0})
        "orbit_orbs":
            for i in 4:
                parts.append({"n": _orb(0.1, accent), "a": i * TAU / 4.0, "r": 0.9, "h": 0.0, "w": 1.6})
        "sparks":
            for i in 5:
                var b = MeshInstance3D.new()
                var bm2 = BoxMesh.new()
                bm2.size = Vector3(0.03, 0.5, 0.03)
                b.mesh = bm2
                b.material_override = _m(accent, 4.0)
                add_child(b)
                parts.append({"n": b, "bolt": true})
        "cross_rings":
            parts.append({"n": _ring(0.9, accent, Vector3(0, 0, 0)), "s": 1.5})
            parts.append({"n": _ring(0.9, accent, Vector3(PI / 2.0, 0, 0)), "s": -1.2})
        "halo":
            var h = _ring(0.45, accent, Vector3.ZERO)
            h.position = Vector3(0, 1.0, 0)
            parts.append({"n": h, "s": 2.0})
        "infinity":
            for i in 3:
                parts.append({"n": _ring(0.85 + i * 0.12, accent, Vector3(0.8 * i, 0.5 * i, 0)), "s": 1.0 + i * 0.5, "hue": true})
        "nova":
            shell = _orb(1.0, accent, 1.5)
            shell.material_override = _m(accent, 1.5, 0.25)
            shell.scale = Vector3(1.0, 1.35, 1.0)


func _process(delta):
    t += delta
    for p in parts:
        var n = p.n
        if p.has("a"):
            p.a += delta * p.get("w", 1.0)
            n.position = Vector3(cos(p.a) * p.r, p.get("h", 0.0) + sin(p.a * 2.0) * 0.1, sin(p.a) * p.r)
            n.rotate_y(delta * 2.0)
        elif p.has("s"):
            n.rotate_y(delta * p.s)
        elif p.has("bolt"):
            n.visible = randf() < 0.45
            n.position = Vector3(randf_range(-0.5, 0.5), randf_range(-0.6, 0.6), randf_range(-0.5, 0.5))
            n.rotation = Vector3(randf() * PI, randf() * PI, randf() * PI)
        if p.get("hue", false):
            n.material_override.emission = Color.from_hsv(fposmod(t * 0.3 + n.get_index() * 0.2, 1.0), 0.7, 1.0)
    for h in hands:
        h.n.rotation.y += delta * h.w
    var mm = mesh_node.material_override
    match kind:
        "jitter":
            mesh_node.position = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * 0.03
            mm.emission_energy_multiplier = 0.4 + randf() * 1.6
        "sparks":
            mm.emission_energy_multiplier = 0.5 + randf() * 2.5
        "prism", "infinity":
            mm.emission = Color.from_hsv(fposmod(t * 0.3, 1.0), 0.7, 1.0)
            mm.emission_energy_multiplier = 0.8
        "blackhole":
            mm.emission_energy_multiplier = 0.1 + 0.2 * sin(t * 3.0)
        "nova":
            var k = 1.0 + 0.12 * sin(t * 4.0)
            shell.scale = Vector3(k, 1.35 * k, k)
            mm.emission_energy_multiplier = 0.8 + 0.6 * sin(t * 4.0)
