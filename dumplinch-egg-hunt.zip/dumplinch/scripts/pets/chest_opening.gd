extends Node3D
## Открытие сундука из инвентаря: камера, тряска, раскрытие крышки, столп света, награда с подсветкой редкости.

const ChestBuilder = preload("res://scripts/world/chest_builder.gd")
const Fx = preload("res://scripts/vfx/fx.gd")

var busy = false
var hud = null


func _ready():
    GameState.request_open_chest.connect(begin)


func _wait(sec):
    await get_tree().create_timer(sec).timeout


func begin(ctype):
    if busy or GameState.chests.get(ctype, 0) <= 0:
        return
    var pl = GameState.player_node
    if pl == null or pl.dead or GameState.cinematic_busy:
        return
    busy = true
    GameState.cinematic_busy = true
    if hud != null:
        hud.close_all()
    # награда определяется и сохраняется ДО анимации: закрытие игры посреди анимации не даст открыть сундук дважды
    var res = GameState.open_chest(ctype)
    SaveSystem.save_game()
    if res != null:
        await _play(ctype, res, pl)
    GameState.cinematic_busy = false
    busy = false


func _play(ctype, res, pl):
    var cd = GameData.CHESTS[ctype]
    pl.set_busy(true, "open_egg")
    var fwd = Vector3(sin(pl.vis.rotation.y), 0, cos(pl.vis.rotation.y))
    var pos = pl.global_position + fwd * 3.2
    GameState.cinematic.emit(pos + Vector3(0, 1.0, 0), 5.0, -0.2, 8.0)
    var chest = ChestBuilder.build_chest(ctype)
    add_child(chest)
    chest.global_position = pos
    chest.rotation.y = pl.vis.rotation.y + PI
    var target_scale = chest.scale
    chest.scale = target_scale * 0.05
    var tw = create_tween()
    tw.tween_property(chest, "scale", target_scale * 1.4, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    AudioManager.play_sfx("pop", 0.8)
    await tw.finished
    var shakes = 3 + cd.rarity + (3 if res.unique != null else 0)
    for i in shakes:
        AudioManager.play_sfx("shake", 0.8 + i * 0.06)
        Fx.vibrate(25)
        var sh = create_tween()
        var dir = 1.0 if i % 2 == 0 else -1.0
        sh.tween_property(chest, "rotation:z", 0.12 * dir, 0.07)
        sh.tween_property(chest, "rotation:z", -0.12 * dir, 0.07)
        sh.tween_property(chest, "rotation:z", 0.0, 0.05)
        await sh.finished
    ChestBuilder.open_lid(chest, 0.4)
    GameState.screen_flash.emit(Color(cd.glow.r, cd.glow.g, cd.glow.b, 0.5 + 0.1 * res.best), 0.7)
    Fx.shake(get_tree(), 0.2 + 0.08 * res.best)
    Fx.vibrate(100)
    Fx.burst(self, pos + Vector3(0, 1.0, 0), cd.glow, 30 + 6 * res.best, 7.0, 1.0, 0.1)
    Fx.shockwave(self, pos, cd.glow, 5.0 + res.best, 0.6)
    AudioManager.play_sfx("epic" if res.best >= 3 else "reward")
    var beam = MeshInstance3D.new()
    var cm = CylinderMesh.new()
    cm.top_radius = 0.5
    cm.bottom_radius = 0.9
    cm.height = 14.0
    cm.radial_segments = 16
    var bm = StandardMaterial3D.new()
    var rc = GameData.rarity_color(res.best)
    bm.albedo_color = Color(rc.r, rc.g, rc.b, 0.4)
    bm.emission_enabled = true
    bm.emission = rc
    bm.emission_energy_multiplier = 2.5
    bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    cm.material = bm
    beam.mesh = cm
    add_child(beam)
    beam.global_position = pos + Vector3(0, 7.0, 0)
    beam.scale = Vector3(0.1, 1.0, 0.1)
    create_tween().tween_property(beam, "scale", Vector3(1.0, 1.0, 1.0), 0.5)
    if res.unique != null:
        GameState.screen_flash.emit(Color(1, 0.95, 0.6, 0.9), 1.0)
        AudioManager.play_sfx("levelup")
        Fx.shake(get_tree(), 0.5)
        for k in 3:
            Fx.shockwave(self, pos, rc, 6.0 + k * 3.0, 0.6 + k * 0.2)
    await _wait(1.0 if res.unique == null else 1.6)
    GameState.reveal_reward.emit(res)
    if hud != null:
        await hud.reward_window.closed
    chest.queue_free()
    beam.queue_free()
    GameState.cinematic.emit(pl.global_position, 7.5, -0.35, 0.01)
    pl.set_busy(false)
