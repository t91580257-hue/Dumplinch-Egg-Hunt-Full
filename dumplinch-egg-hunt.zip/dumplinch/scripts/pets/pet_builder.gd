extends RefCounted
## Процедурные 3D-модели питомцев: 20 базовых форм + аксессуары, цвет и свечение по редкости.
## Крылья называются WingL/WingR (машут), вращающиеся детали лежат в узле Acc.


static func _mat(color, emit = 0.0, alpha = 1.0):
    var m = StandardMaterial3D.new()
    m.albedo_color = Color(color.r, color.g, color.b, alpha)
    m.roughness = 0.6
    if emit > 0.0:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = emit
    if alpha < 1.0:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m


static func _add(parent, mesh, mat, pos, scl = Vector3.ONE, rot = Vector3.ZERO):
    var mi = MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = mat
    mi.position = pos
    mi.scale = scl
    mi.rotation = rot
    parent.add_child(mi)
    return mi


static func _sph(r):
    var m = SphereMesh.new()
    m.radius = r
    m.height = r * 2.0
    m.radial_segments = 14
    m.rings = 7
    return m


static func _cone(r, h):
    var m = CylinderMesh.new()
    m.top_radius = 0.0
    m.bottom_radius = r
    m.height = h
    m.radial_segments = 8
    return m


static func _cyl(r, h):
    var m = CylinderMesh.new()
    m.top_radius = r
    m.bottom_radius = r
    m.height = h
    m.radial_segments = 8
    return m


static func _torus(inner, outer):
    var t = TorusMesh.new()
    t.inner_radius = inner
    t.outer_radius = outer
    t.rings = 24
    t.ring_segments = 6
    return t


static func _wings(body, mat, y, z, span, size):
    if body.find_child("WingL", true, false) != null:
        return
    for s in [-1, 1]:
        var pivot = Node3D.new()
        pivot.name = "WingL" if s < 0 else "WingR"
        pivot.position = Vector3(0.22 * s, y, z)
        body.add_child(pivot)
        _add(pivot, _sph(size), mat, Vector3(span * s, 0, 0), Vector3(1.0, 0.1, 0.7))


static func _eyes(parent, y, z, spread, r, mat):
    for s in [-1, 1]:
        _add(parent, _sph(r), mat, Vector3(spread * s, y, z), Vector3(1, 1.3, 0.7))


static func _fx_particles(root, color, up, amount):
    var p = CPUParticles3D.new()
    p.amount = maxi(3, int(amount * GameState.particle_scale()))
    p.lifetime = 1.2
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    p.emission_sphere_radius = 0.5
    p.direction = Vector3.UP if up else Vector3.ZERO
    p.spread = 25.0 if up else 180.0
    p.initial_velocity_min = 0.3
    p.initial_velocity_max = 0.9
    p.gravity = Vector3.ZERO
    var sm = _sph(0.04)
    sm.material = _mat(color, 3.0)
    p.mesh = sm
    p.position = Vector3(0, 0.5, 0)
    root.add_child(p)


static func _accessories(body, d, dark):
    var acc = Node3D.new()
    acc.name = "Acc"
    acc.position = Vector3(0, 0.6, 0)
    body.add_child(acc)
    var gold = _mat(Color("ffd24a"), 1.2)
    var glow = _mat(d.color.lightened(0.5), 2.0)
    for a in d.get("acc", []):
        match a:
            "halo":
                _add(acc, _torus(0.2, 0.26), gold, Vector3(0, 0.95, 0))
            "ring":
                _add(acc, _torus(0.58, 0.63), glow, Vector3(0, 0.1, 0), Vector3.ONE, Vector3(1.2, 0, 0.25))
            "crown":
                for i in 5:
                    var ang = i * TAU / 5.0
                    _add(acc, _cone(0.05, 0.22), gold, Vector3(cos(ang) * 0.17, 0.9, sin(ang) * 0.17))
            "horns":
                for s in [-1, 1]:
                    _add(body, _cone(0.07, 0.3), dark, Vector3(0.17 * s, 1.1, 0.1), Vector3.ONE, Vector3(0, 0, -0.35 * s))
            "wings":
                _wings(body, _mat(d.color.lightened(0.2), 0.4), 0.8, -0.05, 0.5, 0.3)
            "spikes":
                for i in 5:
                    _add(body, _cone(0.06, 0.28), glow, Vector3((i - 2) * 0.12, 0.82 - absf(i - 2) * 0.05, -0.2), Vector3.ONE, Vector3(-0.4, 0, 0))
            "aura":
                _add(acc, _sph(0.8), _mat(d.color.lightened(0.3), 1.0, 0.22), Vector3(0, 0.0, 0))
            "trail":
                _add(body, _cone(0.25, 0.9), _mat(Color("ff8a2a"), 2.0, 0.6), Vector3(0, 0.6, -0.9), Vector3.ONE, Vector3(-PI / 2.0, 0, 0))
            "flame":
                _fx_particles(body, Color("ff8a2a"), true, 18)
            "eyes3":
                _add(body, _sph(0.06), _mat(Color("ffee66"), 3.0), Vector3(0, 0.95, 0.4), Vector3(1, 1.3, 0.7))
    return acc


static func build_pet(d, form = 0):
    var root = Node3D.new()
    var body = Node3D.new()
    body.name = "Body"
    root.add_child(body)
    var c = d.color
    var emit = [0.0, 0.0, 0.25, 0.5, 0.9, 1.4][clampi(d.rarity, 0, 5)]
    var alpha = 0.8 if (d.shape == "ghost" or d.get("fx", "") == "ghost") else 1.0
    var m = _mat(c, emit, alpha)
    var dark = _mat(c.darkened(0.35), emit * 0.5, alpha)
    var light = _mat(c.lightened(0.45), emit * 0.8)
    var eye = _mat(Color("101010"))
    var glow_eye = _mat(Color("ffee66"), 3.0)
    var white = _mat(Color.WHITE)
    match d.shape:
        "cat", "fox", "wolf":
            _add(body, _sph(0.4), m, Vector3(0, 0.45, 0), Vector3(1, 0.9, 1.15))
            var head = _add(body, _sph(0.28), m, Vector3(0, 0.78, 0.3))
            for s in [-1, 1]:
                _add(head, _cone(0.1, 0.25), dark, Vector3(0.16 * s, 0.26, 0), Vector3.ONE, Vector3(0, 0, -0.2 * s))
                _add(head, _sph(0.04), eye, Vector3(0.1 * s, 0.05, 0.24))
            if d.shape != "cat":
                _add(head, _sph(0.12), dark, Vector3(0, -0.05, 0.27), Vector3(1, 0.8, 1.3))
            _add(body, _sph(0.14 if d.shape != "fox" else 0.2), dark, Vector3(0, 0.55, -0.5), Vector3(0.8, 0.8, 1.8))
        "bunny":
            _add(body, _sph(0.38), m, Vector3(0, 0.4, 0))
            var hb = _add(body, _sph(0.26), m, Vector3(0, 0.78, 0.15))
            for s in [-1, 1]:
                _add(hb, _sph(0.09), dark, Vector3(0.1 * s, 0.4, 0), Vector3(0.7, 2.6, 0.7))
                _add(hb, _sph(0.04), eye, Vector3(0.1 * s, 0.05, 0.22))
            _add(body, _sph(0.1), white, Vector3(0, 0.35, -0.4))
        "dragon":
            _add(body, _sph(0.38), m, Vector3(0, 0.42, 0), Vector3(1, 0.9, 1.2))
            var hd = _add(body, _sph(0.24), m, Vector3(0, 0.78, 0.3))
            for s in [-1, 1]:
                _add(hd, _cone(0.06, 0.2), white, Vector3(0.12 * s, 0.22, -0.05))
                _add(hd, _sph(0.04), eye, Vector3(0.1 * s, 0.05, 0.2))
            _wings(body, dark, 0.65, -0.1, 0.4, 0.3)
            _add(body, _cone(0.12, 0.6), dark, Vector3(0, 0.3, -0.55), Vector3.ONE, Vector3(1.9, 0, 0))
        "ghost":
            _add(body, _sph(0.4), m, Vector3(0, 0.6, 0), Vector3(1, 1.2, 1))
            _add(body, _cone(0.4, 0.4), m, Vector3(0, 0.2, 0), Vector3.ONE, Vector3(PI, 0, 0))
            _eyes(body, 0.7, 0.34, 0.14, 0.07, eye)
        "golem":
            var bm = BoxMesh.new()
            bm.size = Vector3(0.7, 0.7, 0.55)
            _add(body, bm, m, Vector3(0, 0.45, 0))
            var hm = BoxMesh.new()
            hm.size = Vector3(0.4, 0.35, 0.35)
            _add(body, hm, dark, Vector3(0, 0.98, 0.05))
            for s in [-1, 1]:
                _add(body, _sph(0.06), glow_eye, Vector3(0.1 * s, 1.0, 0.24))
                var am = BoxMesh.new()
                am.size = Vector3(0.18, 0.5, 0.18)
                _add(body, am, dark, Vector3(0.46 * s, 0.45, 0))
        "dumpling":
            _add(body, _sph(0.4), m, Vector3(0, 0.38, 0), Vector3(1.25, 0.85, 1.0))
            for i in 5:
                var x = lerpf(-0.4, 0.4, i / 4.0)
                _add(body, _sph(0.07), dark, Vector3(x, 0.65 - absf(x) * 0.35, 0), Vector3(1, 1.4, 1))
            for s in [-1, 1]:
                _add(body, _sph(0.05), eye, Vector3(0.16 * s, 0.4, 0.36))
        "monster":
            _add(body, _sph(0.42), m, Vector3(0, 0.5, 0))
            _add(body, _sph(0.17), white, Vector3(0, 0.6, 0.32))
            _add(body, _sph(0.08), eye, Vector3(0, 0.6, 0.45))
            for s in [-1, 1]:
                _add(body, _cone(0.08, 0.3), dark, Vector3(0.22 * s, 0.95, 0), Vector3.ONE, Vector3(0, 0, -0.3 * s))
        "orb":
            _add(body, _sph(0.42), m, Vector3(0, 0.75, 0))
            _add(body, _torus(0.58, 0.66), _mat(c.lightened(0.7), 2.5), Vector3(0, 0.75, 0), Vector3.ONE, Vector3(1.2, 0, 0.2))
            _add(body, _sph(0.2), _mat(c.lightened(0.5), 1.5, 0.5), Vector3(0, 0.75, 0))
        "meteor":
            _add(body, _sph(0.4), dark, Vector3(0, 0.7, 0), Vector3(1, 0.85, 1.1))
            for p in [Vector3(0.25, 0.85, 0.2), Vector3(-0.2, 0.6, 0.3), Vector3(0.1, 0.95, -0.15), Vector3(-0.3, 0.8, -0.1)]:
                _add(body, _sph(0.07), _mat(Color("ff7a20"), 3.0), p)
            _add(body, _cone(0.3, 1.0), _mat(Color("ff8a2a"), 2.0, 0.55), Vector3(0, 0.75, -0.8), Vector3.ONE, Vector3(-PI / 2.0, 0, 0))
            _eyes(body, 0.75, 0.38, 0.14, 0.05, glow_eye)
        "unicorn":
            _add(body, _sph(0.4), m, Vector3(0, 0.55, 0), Vector3(0.8, 0.75, 1.2))
            _add(body, _sph(0.22), m, Vector3(0, 0.98, 0.5))
            _add(body, _cone(0.05, 0.32), _mat(Color("ffe070"), 1.5), Vector3(0, 1.28, 0.58), Vector3.ONE, Vector3(0.3, 0, 0))
            for s in [-1, 1]:
                _add(body, _cone(0.05, 0.14), dark, Vector3(0.1 * s, 1.18, 0.42))
                _add(body, _sph(0.035), eye, Vector3(0.1 * s, 1.0, 0.68))
                for z in [-0.35, 0.35]:
                    _add(body, _cyl(0.06, 0.45), dark, Vector3(0.2 * s, 0.22, z))
            var rainbow = [Color("ff4a4a"), Color("ffa03a"), Color("ffe03a"), Color("4adf5a"), Color("3aa8ff")]
            for i in 5:
                _add(body, _sph(0.08), _mat(rainbow[i], 1.0), Vector3(0, 1.0 - i * 0.07, 0.3 - i * 0.2))
            _add(body, _sph(0.12), _mat(rainbow[4], 1.0), Vector3(0, 0.6, -0.65), Vector3(0.8, 1.4, 0.8))
        "angel":
            _add(body, _sph(0.34), m, Vector3(0, 0.55, 0), Vector3(1, 1.2, 1))
            _add(body, _sph(0.24), light, Vector3(0, 1.1, 0))
            _eyes(body, 1.12, 0.2, 0.08, 0.035, eye)
            _wings(body, _mat(Color.WHITE, 0.6), 0.75, -0.1, 0.5, 0.34)
            _add(body, _torus(0.2, 0.25), _mat(Color("ffd24a"), 2.0), Vector3(0, 1.5, 0))
        "phoenix":
            _add(body, _sph(0.32), m, Vector3(0, 0.7, 0), Vector3(0.9, 0.9, 1.3))
            _add(body, _sph(0.2), m, Vector3(0, 1.0, 0.36))
            _add(body, _cone(0.06, 0.2), _mat(Color("ffd24a"), 1.0), Vector3(0, 0.98, 0.58), Vector3.ONE, Vector3(PI / 2.0, 0, 0))
            _eyes(body, 1.05, 0.5, 0.09, 0.035, eye)
            _wings(body, _mat(c.lightened(0.15), 0.9), 0.8, 0.0, 0.7, 0.36)
            for i in 3:
                _add(body, _cone(0.09, 0.9), _mat(Color("ffb02a") if i != 1 else Color("ff5a1a"), 2.2, 0.85), Vector3((i - 1) * 0.15, 0.55, -0.75), Vector3.ONE, Vector3(-1.9 + 0.1 * (i - 1), 0, 0))
        "demon":
            _add(body, _sph(0.4), m, Vector3(0, 0.5, 0))
            _add(body, _sph(0.28), m, Vector3(0, 1.0, 0.1))
            for s in [-1, 1]:
                _add(body, _cone(0.07, 0.32), dark, Vector3(0.15 * s, 1.3, 0.1), Vector3.ONE, Vector3(0, 0, -0.35 * s))
            _eyes(body, 1.02, 0.34, 0.1, 0.05, glow_eye)
            _wings(body, dark, 0.7, -0.2, 0.45, 0.3)
            _add(body, _cone(0.06, 0.7), dark, Vector3(0, 0.3, -0.5), Vector3.ONE, Vector3(-2.2, 0, 0))
            _add(body, _cone(0.1, 0.2), glow_eye, Vector3(0, 0.05, -0.8), Vector3.ONE, Vector3(-PI / 2.0, 0, 0))
        "serpent":
            for i in 8:
                var r = 0.3 * (1.0 - i * 0.08)
                var yy = 0.28 + maxf(0.0, 0.55 - i * 0.22)
                _add(body, _sph(r), m if i % 2 == 0 else dark, Vector3(sin(i * 0.9) * 0.35, yy, 0.35 - i * 0.3))
            _eyes(body, 0.95, 0.5, 0.1, 0.05, glow_eye)
        "star":
            _add(body, _sph(0.25), _mat(c, maxf(emit, 1.5)), Vector3(0, 0.85, 0))
            for i in 5:
                var ang = i * TAU / 5.0
                _add(body, _cone(0.14, 0.5), _mat(c.lightened(0.3), 1.8), Vector3(cos(ang) * 0.42, 0.85 + sin(ang) * 0.42, 0), Vector3.ONE, Vector3(0, 0, ang - PI / 2.0))
            _eyes(body, 0.88, 0.22, 0.08, 0.04, eye)
        "imp":
            _add(body, _sph(0.24), m, Vector3(0, 0.4, 0))
            _add(body, _sph(0.26), m, Vector3(0, 0.8, 0.05))
            for s in [-1, 1]:
                _add(body, _cone(0.05, 0.22), dark, Vector3(0.14 * s, 1.05, 0.05), Vector3.ONE, Vector3(0, 0, -0.3 * s))
            _eyes(body, 0.84, 0.24, 0.09, 0.05, glow_eye)
            _wings(body, dark, 0.55, -0.05, 0.35, 0.22)
            _add(body, _cone(0.04, 0.45), dark, Vector3(0, 0.25, -0.3), Vector3.ONE, Vector3(-2.3, 0, 0))
        "turtle":
            _add(body, _sph(0.45), m, Vector3(0, 0.4, 0), Vector3(1, 0.6, 1))
            for i in 4:
                var a2 = i * TAU / 4.0 + 0.7
                _add(body, _cone(0.08, 0.3), light, Vector3(cos(a2) * 0.22, 0.65, sin(a2) * 0.22))
            _add(body, _sph(0.16), dark, Vector3(0, 0.35, 0.5))
            _eyes(body, 0.4, 0.62, 0.07, 0.03, eye)
            for s in [-1, 1]:
                for z in [-0.28, 0.28]:
                    _add(body, _sph(0.1), dark, Vector3(0.32 * s, 0.1, z), Vector3(1, 0.6, 1.2))
        _:
            _add(body, _sph(0.4), m, Vector3(0, 0.4, 0))
            _eyes(body, 0.5, 0.34, 0.14, 0.06, eye)
    _accessories(body, d, dark)
    var fxk = d.get("fx", "")
    match fxk:
        "sparkle":
            _fx_particles(root, c.lightened(0.5), true, 10)
        "sparks":
            _fx_particles(root, Color("ffee60"), false, 10)
        "flames":
            _fx_particles(root, Color("ff8a2a"), true, 14)
        "prism":
            _fx_particles(root, Color("ff9ae0"), false, 10)
        "ghost":
            _fx_particles(root, Color("c8f0ff"), true, 8)
    if d.rarity >= 3 and fxk == "":
        _fx_particles(root, c.lightened(0.4), true, 8)
    root.scale = Vector3.ONE * (0.9 + 0.25 * form) * float(d.get("scale", 1.0))
    return root
