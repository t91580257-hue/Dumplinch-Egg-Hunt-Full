extends Node3D
## Питомцы-спутники: четыре способа движения (ходьба, полёт, парение, телепортация),
## анимации появления/ожидания/движения. Не используют физику, поэтому не застревают.

const PetBuilder = preload("res://scripts/pets/pet_builder.gd")
const Fx = preload("res://scripts/vfx/fx.gd")

var followers = []
var _t = 0.0
var _known = []


func _ready():
    add_to_group("pet_manager")
    GameState.pets_changed.connect(rebuild)
    rebuild()


func rebuild():
    for f in followers:
        if is_instance_valid(f.node):
            f.node.queue_free()
    followers.clear()
    var uids = []
    var pl = GameState.player_node
    for p in GameState.equipped_pets():
        var d = GameData.pet(p.id)
        var n = PetBuilder.build_pet(d, p.form)
        add_child(n)
        if pl != null:
            n.global_position = pl.global_position + Vector3(0, 0.2, -1.5)
        var f = {"node": n, "uid": p.uid, "cd": randf() * 1.2, "lunge": 0.0, "target": null, "burst": false,
            "move": d.get("move", "walk"), "wl": n.find_child("WingL", true, false), "wr": n.find_child("WingR", true, false),
            "acc": n.find_child("Acc", true, false), "blink": 0.0, "tscale": n.scale, "tp_cd": 0.0, "spawn": 0.0,
            "color": d.color, "pitch": d.get("pitch", 1.0)}
        followers.append(f)
        uids.append(p.uid)
        if pl != null and not _known.has(p.uid):
            _spawn_anim(f)
    _known = uids


func _spawn_anim(f):
    f.spawn = 0.6
    f.node.scale = Vector3.ONE * 0.05
    var tw = create_tween()
    tw.tween_property(f.node, "scale", f.tscale, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    Fx.burst(self, f.node.global_position + Vector3(0, 0.6, 0), f.color.lightened(0.3), 16, 4.0, 0.7)
    AudioManager.play_sfx("pet", f.pitch)


func call_pets():
    for f in followers:
        f.cd = 0.0
        f.burst = true
    var pl = GameState.player_node
    if pl != null:
        Fx.shockwave(self, pl.global_position, Color("ffd0a0"), 5.0, 0.4)


func _nearest_enemy(pos, rng):
    var te = GameState.target_enemy
    if te != null and is_instance_valid(te) and te.get("dead") != true and te.global_position.distance_to(pos) < rng:
        return te
    var best = null
    var bd = rng
    for grp in ["enemies", "bosses"]:
        for n in get_tree().get_nodes_in_group(grp):
            if is_instance_valid(n) and n.get("dead") != true:
                var d = n.global_position.distance_to(pos)
                if d < bd:
                    bd = d
                    best = n
    return best


func _process(delta):
    var pl = GameState.player_node
    if pl == null:
        return
    _t += delta
    var n = followers.size()
    var yaw = pl.vis.rotation.y
    var back = -Vector3(sin(yaw), 0, cos(yaw))
    var right = Vector3(cos(yaw), 0, -sin(yaw))
    for i in n:
        var f = followers[i]
        var node = f.node
        if not is_instance_valid(node):
            continue
        var mv = f.move
        var sc = f.tscale.x
        var off = back * (2.0 + 0.3 * (i % 2) + 0.4 * sc) + right * ((i - (n - 1) / 2.0) * (1.4 + 0.3 * sc))
        var target = pl.global_position + off
        target.y = 0.0
        f.spawn = maxf(0.0, f.spawn - delta)
        # телепортация: исчезает и появляется рядом с героем
        if mv == "teleport":
            f.tp_cd -= delta
            if f.blink > 0.0:
                f.blink -= delta
                node.scale = f.tscale * clampf(f.blink / 0.25, 0.0, 1.0)
                if f.blink <= 0.0:
                    node.global_position = Vector3(target.x, node.global_position.y, target.z)
                    node.scale = f.tscale
                    Fx.burst(self, node.global_position + Vector3(0, 0.6, 0), f.color.lightened(0.3), 10, 3.0, 0.4)
                continue
            if node.global_position.distance_to(target) > 4.5 and f.tp_cd <= 0.0:
                f.blink = 0.25
                f.tp_cd = 1.2
                Fx.burst(self, node.global_position + Vector3(0, 0.6, 0), f.color.lightened(0.3), 10, 3.0, 0.4)
                AudioManager.play_sfx("whoosh", 1.4)
                continue
        var cur = node.global_position
        var np = cur.lerp(target, 1.0 - exp(-(1.5 if mv == "teleport" else 4.0) * delta))
        var moving = Vector2(np.x - cur.x, np.z - cur.z).length() > 0.01
        var y = 0.05
        match mv:
            "fly":
                y = (1.5 + 0.4 * sc) + sin(_t * 2.5 + i) * 0.25
            "hover":
                y = (0.9 + 0.2 * sc) + sin(_t * 1.4 + i) * 0.15
            "teleport":
                y = 0.7 + sin(_t * 2.0 + i) * 0.1
            _:
                y = 0.05 + (absf(sin(_t * 8.0 + i)) * 0.18 if moving else sin(_t * 2.0 + i) * 0.03 + 0.03)
        np.y = y
        if f.lunge > 0.0 and f.target != null and is_instance_valid(f.target):
            f.lunge -= delta
            var tp = f.target.global_position
            np = np.lerp(Vector3(tp.x, np.y, tp.z), sin((0.35 - f.lunge) / 0.35 * PI) * 0.7)
        node.global_position = np
        # анимации: крылья, вращающиеся детали, дыхание
        if f.wl != null:
            var flap = sin(_t * (16.0 if mv == "fly" else 7.0) + i) * 0.55
            f.wl.rotation.z = flap
            f.wr.rotation.z = -flap
        if f.acc != null:
            f.acc.rotation.y += delta * 1.6
        if f.spawn <= 0.0 and f.blink <= 0.0:
            node.scale = f.tscale * (1.0 + sin(_t * 3.0 + i) * 0.03)
        var look = target - cur
        look.y = 0
        if look.length() > 0.05:
            node.rotation.y = lerp_angle(node.rotation.y, atan2(look.x, look.z), 1.0 - exp(-8.0 * delta))
        f.cd -= delta
        if f.cd <= 0.0 and not pl.dead and not GameState.in_menu:
            var tgt = _nearest_enemy(pl.global_position, 14.0)
            if tgt != null:
                var p = GameState.get_pet(f.uid)
                if p != null:
                    var mult = 3.0 if f.burst else 1.0
                    f.burst = false
                    var dmg = GameState.pet_power(p) * 0.7 * mult
                    f.lunge = 0.35
                    f.target = tgt
                    f.cd = 1.4
                    tgt.hit(dmg, false, node.global_position, 0.6)
                    Fx.burst(get_parent(), tgt.global_position + Vector3(0, 1, 0), f.color, 8, 3.5, 0.4)
            else:
                f.cd = 0.4
