extends RefCounted
## Процедурные текстуры (без внешних файлов): тесто, земля, узоры яиц.


static func noise_texture(c1, c2, size = 64, freq = 0.07, seed_val = 1):
    var n = FastNoiseLite.new()
    n.seed = seed_val
    n.frequency = freq
    var g = n.get_seamless_image(size, size)
    var img = Image.create(size, size, false, Image.FORMAT_RGBA8)
    for y in size:
        for x in size:
            var v = clampf(g.get_pixel(x, y).r, 0.0, 1.0)
            img.set_pixel(x, y, c1.lerp(c2, v))
    return ImageTexture.create_from_image(img)


static func _hash(a, b):
    return fposmod(sin(float(a) * 127.1 + float(b) * 311.7) * 43758.5453, 1.0)


static func egg_texture(base, accent, pattern, size = 128):
    var img = Image.create(size, size, false, Image.FORMAT_RGBA8)
    img.fill(base)
    for y in size:
        var v = float(y) / size
        for x in size:
            var u = float(x) / size
            var col = base
            match pattern:
                "stripes":
                    if fposmod(v * 6.0, 1.0) < 0.2:
                        col = accent
                "zigzag":
                    var z = absf(fposmod(u * 8.0, 1.0) * 2.0 - 1.0) * 0.25
                    if fposmod(v * 5.0 + z, 1.0) < 0.22:
                        col = accent
                "spots":
                    var cx = int(u * 6.0)
                    var cy = int(v * 5.0)
                    var px = (cx + 0.3 + 0.4 * _hash(cx, cy)) / 6.0
                    var py = (cy + 0.3 + 0.4 * _hash(cy, cx + 7)) / 5.0
                    if Vector2(u - px, (v - py) * 1.2).length() < 0.055:
                        col = accent
                "rainbow":
                    col = base.lerp(Color.from_hsv(fposmod(v * 3.0 + u * 0.3, 1.0), 0.7, 1.0), 0.75)
            img.set_pixel(x, y, col)
    return ImageTexture.create_from_image(img)
