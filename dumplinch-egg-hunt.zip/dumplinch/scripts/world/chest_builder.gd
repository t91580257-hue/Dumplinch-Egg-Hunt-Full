extends RefCounted
## Процедурные 3D-модели сундуков: у каждого вида своя форма, материалы, свечение и анимация.
## Метаданные модели: lid (крышка), orbs (вращающиеся сферы), glow (материал свечения), spin (вращающийся узел).


static func _m(c, emit = 0.0, rough = 0.7, metal = 0.0, alpha = 1.0):
    var m = StandardMaterial3D.new()
    m.albedo_color = Color(c.r, c.g, c.b, alpha)
    m.roughness = rough
    m.metallic = metal
    if emit > 0.0:
        m.emission_enabled = true
        m.emission = c
        m.emission_energy_multiplier = emit
    if alpha < 1.0:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m


static func _box(parent, size, mat, pos, rot = Vector3.ZERO):
    var mi = MeshInstance3D.new()
    var b = BoxMesh.new()
    b.size = size
    mi.mesh = b
    mi.material_override = mat
    mi.position = pos
    mi.rotation = rot
    parent.add_child(mi)
    return mi


static func _sph(parent, r, mat, pos, scl = Vector3.ONE):
    var mi = MeshInstance3D.new()
    var s = SphereMesh.new()
    s.radius = r
    s.height = r * 2.0
    s.radial_segments = 12
    s.rings = 6
    mi.mesh = s
    mi.material_override = mat
    mi.position = pos
    mi.scale = scl
    parent.add_child(mi)
    return mi


static func _cone(parent, r, h, mat, pos, rot = Vector3.ZERO):
    var mi = MeshInstance3D.new()
    var c = CylinderMesh.new()
    c.top_radius = 0.0
    c.bottom_radius = r
    c.height = h
    c.radial_segments = 6
    mi.mesh = c
    mi.material_override = mat
    mi.position = pos
    mi.rotation = rot
    parent.add_child(mi)
    return mi


static func _particles(parent, color, amount, radius, speed):
    var p = CPUParticles3D.new()
    p.amount = maxi(3, int(amount * GameState.particle_scale()))
    p.lifetime = 1.6
    p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    p.emission_sphere_radius = radius
    p.direction = Vector3.UP
    p.spread = 40.0
    p.initial_velocity_min = speed * 0.5
    p.initial_velocity_max = speed
    p.gravity = Vector3.ZERO
    var sm = SphereMesh.new()
    sm.radius = 0.04
    sm.height = 0.08
    sm.radial_segments = 6
    sm.rings = 3
    sm.material = _m(color, 3.0)
    p.mesh = sm
    p.position = Vector3(0, 0.6, 0)
    parent.add_child(p)


static func build_chest(ctype):
    var cd = GameData.CHESTS[ctype]
    var root = Node3D.new()
    var body = Node3D.new()
    body.name = "Body"
    root.add_child(body)
    var lid = Node3D.new()
    lid.name = "Lid"
    lid.position = Vector3(0, 0.6, -0.35)
    root.add_child(lid)
    var orbs = []
    var glow = null
    var spin = null
    var c = cd.color
    match ctype:
        "common":
            var wood = _m(c, 0.0, 0.9)
            var iron = _m(Color("3a3a42"), 0.0, 0.5, 0.6)
            _box(body, Vector3(1.0, 0.6, 0.7), wood, Vector3(0, 0.3, 0))
            _box(lid, Vector3(1.0, 0.25, 0.7), wood, Vector3(0, 0.12, 0.35))
            for x in [-0.35, 0.35]:
                _box(body, Vector3(0.1, 0.62, 0.74), iron, Vector3(x, 0.3, 0))
                _box(lid, Vector3(0.1, 0.27, 0.74), iron, Vector3(x, 0.12, 0.35))
            _box(body, Vector3(0.14, 0.18, 0.06), _m(Color("ffd24a"), 0.6), Vector3(0, 0.52, 0.37))
        "rare":
            var steel = _m(c.darkened(0.3), 0.0, 0.35, 0.7)
            var silver = _m(Color("d8e4f0"), 0.0, 0.25, 0.9)
            glow = _m(Color("5ac8ff"), 2.2)
            _box(body, Vector3(1.05, 0.62, 0.74), steel, Vector3(0, 0.31, 0))
            _box(lid, Vector3(1.05, 0.28, 0.74), steel, Vector3(0, 0.13, 0.35))
            _box(body, Vector3(1.1, 0.08, 0.78), silver, Vector3(0, 0.6, 0))
            _box(lid, Vector3(1.1, 0.08, 0.78), silver, Vector3(0, 0.0, 0.35))
            for x in [-0.3, 0.0, 0.3]:
                _sph(body, 0.07, glow, Vector3(x, 0.38, 0.38), Vector3(1, 1.2, 0.6))
            _particles(root, Color("9ad0ff"), 6, 0.5, 0.4)
        "golden":
            var gold = _m(c, 0.5, 0.25, 1.0)
            glow = _m(Color("ff3a4a"), 2.5)
            _box(body, Vector3(1.05, 0.62, 0.74), gold, Vector3(0, 0.31, 0))
            _box(lid, Vector3(1.05, 0.28, 0.74), gold, Vector3(0, 0.13, 0.35))
            _box(body, Vector3(1.12, 0.07, 0.8), _m(Color("fff0a0"), 0.8, 0.2, 1.0), Vector3(0, 0.6, 0))
            _sph(body, 0.1, glow, Vector3(0, 0.45, 0.39), Vector3(1, 1.2, 0.6))
            for x in [-0.3, 0.0, 0.3]:
                _cone(lid, 0.1, 0.25, gold, Vector3(x, 0.38, 0.35))
            _particles(root, Color("fff0a0"), 10, 0.55, 0.5)
        "magic":
            var wood = _m(Color("4a2a7a"), 0.5, 0.5)
            glow = _m(c, 2.5)
            _box(body, Vector3(1.0, 0.6, 0.7), wood, Vector3(0, 0.3, 0))
            _box(lid, Vector3(1.0, 0.25, 0.7), wood, Vector3(0, 0.12, 0.35))
            for x in [-0.3, 0.3]:
                _box(body, Vector3(0.06, 0.5, 0.72), glow, Vector3(x, 0.3, 0))
            var rune = MeshInstance3D.new()
            var tm = TorusMesh.new()
            tm.inner_radius = 0.85
            tm.outer_radius = 0.92
            tm.rings = 28
            tm.ring_segments = 6
            rune.mesh = tm
            rune.material_override = glow
            rune.position = Vector3(0, 0.05, 0)
            rune.scale = Vector3(1, 0.3, 1)
            root.add_child(rune)
            spin = rune
            for i in 3:
                orbs.append(_sph(root, 0.12, glow, Vector3(0, 1.0, 0)))
            _particles(root, Color("e0b0ff"), 14, 0.7, 0.7)
        "legendary":
            var white = _m(Color("fff6e0"), 0.4, 0.3, 0.6)
            var gold = _m(Color("ffd24a"), 0.8, 0.25, 1.0)
            glow = _m(Color("ffe9a0"), 3.0)
            _box(body, Vector3(1.1, 0.65, 0.78), white, Vector3(0, 0.325, 0))
            _box(lid, Vector3(1.1, 0.3, 0.78), white, Vector3(0, 0.14, 0.35))
            for sx in [-1, 1]:
                for sz in [-1, 1]:
                    _box(body, Vector3(0.12, 0.7, 0.12), gold, Vector3(0.53 * sx, 0.33, 0.37 * sz))
            _box(body, Vector3(1.16, 0.08, 0.84), gold, Vector3(0, 0.64, 0))
            _sph(lid, 0.14, glow, Vector3(0, 0.34, 0.35))
            var beam = MeshInstance3D.new()
            var cm = CylinderMesh.new()
            cm.top_radius = 0.35
            cm.bottom_radius = 0.5
            cm.height = 16.0
            cm.radial_segments = 12
            beam.mesh = cm
            beam.material_override = _m(Color("fff0b0"), 2.0, 1.0, 0.0, 0.22)
            beam.position = Vector3(0, 8.0, 0)
            root.add_child(beam)
            for i in 4:
                orbs.append(_cone(root, 0.1, 0.35, glow, Vector3(0, 1.0, 0)))
            _particles(root, Color("fff0a0"), 20, 0.8, 0.9)
            root.scale = Vector3(1.3, 1.3, 1.3)
        "secret":
            var stone = _m(Color("2a2a34"), 0.0, 1.0)
            glow = _m(Color("40ffe0"), 3.0)
            _box(body, Vector3(1.0, 0.6, 0.7), stone, Vector3(0, 0.3, 0))
            _box(lid, Vector3(1.0, 0.25, 0.7), stone, Vector3(0, 0.12, 0.35))
            for x in [-0.28, 0.28]:
                _sph(lid, 0.07, glow, Vector3(x, 0.14, 0.7), Vector3(1, 1.4, 0.6))
            for x in [-0.3, 0.0, 0.3]:
                _box(body, Vector3(0.1, 0.03, 0.04), glow, Vector3(x, 0.3, 0.36))
            for sx in [-1, 1]:
                for sz in [-1, 1]:
                    _cone(body, 0.07, 0.3, stone, Vector3(0.5 * sx, 0.7, 0.33 * sz))
            _particles(root, Color("5affd8"), 6, 0.6, 0.3)
    root.set_meta("lid", lid)
    root.set_meta("orbs", orbs)
    root.set_meta("glow", glow)
    root.set_meta("spin", spin)
    return root


static func open_lid(root, dur = 0.5):
    var lid = root.get_meta("lid")
    var tw = root.create_tween()
    tw.tween_property(lid, "rotation:x", -1.95, dur).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
