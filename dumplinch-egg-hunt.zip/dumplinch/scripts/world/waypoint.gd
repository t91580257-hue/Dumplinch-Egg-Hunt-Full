extends Node3D
## Точка телепорта (как в Genshin Impact): активируйте её, затем телепортируйтесь с карты. Также лечит.

const Fx = preload("res://scripts/vfx/fx.gd")
var region = 0
var t = 0.0
var glow
var ring


func setup(r):
    region = r


func _ready():
    add_to_group("interactables")
    var stone = StandardMaterial3D.new()
    stone.albedo_color = Color("7a7a90")
    stone.roughness = 0.7
    var gm = MeshInstance3D.new()
    var cm = CylinderMesh.new()
    cm.top_radius = 1.0
    cm.bottom_radius = 1.4
    cm.height = 0.5
    cm.radial_segments = 16
    gm.mesh = cm
    gm.material_override = stone
    gm.position = Vector3(0, 0.25, 0)
    add_child(gm)
    glow = StandardMaterial3D.new()
    glow.albedo_color = Color("6af0ff")
    glow.emission_enabled = true
    glow.emission = Color("6af0ff")
    glow.emission_energy_multiplier = 2.5
    glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    var pil = MeshInstance3D.new()
    var pm = CylinderMesh.new()
    pm.top_radius = 0.18
    pm.bottom_radius = 0.28
    pm.height = 2.4
    pm.radial_segments = 8
    pil.mesh = pm
    pil.material_override = glow
    pil.position = Vector3(0, 1.7, 0)
    add_child(pil)
    ring = MeshInstance3D.new()
    var tm = TorusMesh.new()
    tm.inner_radius = 0.7
    tm.outer_radius = 0.78
    tm.rings = 24
    tm.ring_segments = 6
    ring.mesh = tm
    ring.material_override = glow
    ring.position = Vector3(0, 1.9, 0)
    add_child(ring)
    var beam = MeshInstance3D.new()
    var bm = CylinderMesh.new()
    bm.top_radius = 0.3
    bm.bottom_radius = 0.6
    bm.height = 40.0
    bm.radial_segments = 8
    var bmat = StandardMaterial3D.new()
    bmat.albedo_color = Color(0.4, 0.95, 1.0, 0.18)
    bmat.emission_enabled = true
    bmat.emission = Color("6af0ff")
    bmat.emission_energy_multiplier = 1.5
    bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    beam.mesh = bm
    beam.material_override = bmat
    beam.position = Vector3(0, 20.0, 0)
    add_child(beam)


func _process(delta):
    t += delta
    ring.rotation.y += delta * 1.5
    ring.position.y = 1.9 + sin(t * 2.0) * 0.15
    var on = GameState.waypoints.has(region)
    glow.emission_energy_multiplier = (2.5 if on else 0.5) + sin(t * 3.0) * 0.5


func interact_prompt():
    if GameState.waypoints.has(region):
        return "Точка телепорта: отдохнуть (карта - телепорт)"
    return "Активировать точку телепорта"


func interact(_player):
    if GameState.unlock_waypoint(region):
        Fx.burst(get_parent(), global_position + Vector3(0, 2, 0), Color("6af0ff"), 40, 8.0, 1.0, 0.1)
        Fx.shockwave(get_parent(), global_position, Color("6af0ff"), 8.0, 0.7)
        Fx.vibrate(60)
    GameState.heal(9999)
    GameState.message.emit("Здоровье восстановлено")
