extends Node3D
## Сундук в мире. Подбирается в инвентарь (не открывается сразу).
## Обычные виды появляются снова через несколько минут реального времени (время хранится в сохранении);
## секретные находятся один раз.

const ChestBuilder = preload("res://scripts/world/chest_builder.gd")
const Fx = preload("res://scripts/vfx/fx.gd")

var chest_id = ""
var ctype = "common"
var region = 0
var secret = false
var active = true
var model
var t = 0.0
var _check_t = 0.0


func setup(id, r, type = "common"):
    chest_id = id
    region = r
    ctype = type
    secret = (type == "secret")


func _available():
    if secret:
        return not GameState.opened_chests.has(chest_id)
    return GameState.chest_respawn.get(chest_id, 0.0) <= Time.get_unix_time_from_system()


func _ready():
    add_to_group("interactables")
    model = ChestBuilder.build_chest(ctype)
    add_child(model)
    t = randf() * 6.0
    active = _available()
    visible = active


func interact_prompt():
    if not active:
        return ""
    return "Взять: " + GameData.CHESTS[ctype].name


func interact(_player):
    if not active:
        return
    active = false
    var cd = GameData.CHESTS[ctype]
    GameState.add_chest(ctype, 1)
    GameState.stats["chests_found"] += 1
    if secret:
        GameState.opened_chests.append(chest_id)
    else:
        GameState.chest_respawn[chest_id] = Time.get_unix_time_from_system() + float(cd.respawn)
    GameState.message.emit("В инвентарь: " + cd.name)
    GameState._check_all()
    AudioManager.play_sfx("chest" if cd.rarity < 3 else "epic")
    Fx.burst(get_parent(), global_position + Vector3(0, 0.8, 0), cd.glow, 24, 6.0, 0.9, 0.1)
    Fx.shockwave(get_parent(), global_position, cd.glow, 3.0, 0.4)
    Fx.vibrate(40)
    ChestBuilder.open_lid(model, 0.25)
    var tw = create_tween()
    tw.tween_interval(0.3)
    tw.tween_property(self, "scale", Vector3(0.01, 0.01, 0.01), 0.3)
    tw.tween_callback(_hide)
    SaveSystem.save_game()
    _check_t = 3.0


func _hide():
    visible = false
    scale = Vector3.ONE
    model.get_meta("lid").rotation.x = 0.0


func _process(delta):
    t += delta
    if not active:
        _check_t -= delta
        if _check_t <= 0.0:
            _check_t = 3.0
            if not secret and _available():
                active = true
                visible = true
                scale = Vector3(0.01, 0.01, 0.01)
                create_tween().tween_property(self, "scale", Vector3.ONE, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
                Fx.burst(get_parent(), global_position + Vector3(0, 0.8, 0), GameData.CHESTS[ctype].glow, 12, 3.0, 0.6)
        return
    var pl = GameState.player_node
    if pl != null and pl.global_position.distance_to(global_position) > 90.0:
        return
    model.rotation.y = sin(t * 0.7) * 0.12
    if ctype == "magic" or ctype == "legendary":
        model.position.y = 0.12 + sin(t * 2.0) * 0.08
    var g = model.get_meta("glow")
    if g != null:
        g.emission_energy_multiplier = 1.8 + 1.0 * sin(t * 3.0)
    var spin = model.get_meta("spin")
    if spin != null:
        spin.rotate_y(delta * 1.5)
    var orbs = model.get_meta("orbs")
    for i in orbs.size():
        var a = t * 1.6 + i * TAU / orbs.size()
        orbs[i].position = Vector3(cos(a) * 0.9, 1.0 + sin(t * 2.0 + i) * 0.15, sin(a) * 0.9)
