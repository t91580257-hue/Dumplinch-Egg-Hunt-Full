extends Node
## Онлайн: ENet (UDP). Один игрок «Создать сервер» (или выделенный сервер scenes/server.tscn), остальные подключаются по IP.
## Синхронизируются: список игроков, позиции и анимации героев, чат, объявления и кик администратора.
## НЕ синхронизируются: враги, боссы, сундуки, инвентарь (у каждого игрока свой мир и прогресс).
## Трафик не шифруется.

signal status_changed(text)
signal roster_changed
signal chat_received(nick, text, admin)
signal remote_state(id, pos, yaw, anim, hat, nick)
signal peer_left(id)
signal announcement(text)

const DEFAULT_PORT = 7777
const PROTOCOL = 2

var roster = {}
var is_online = false
var is_server = false
var server_only = false
var status = "Не в сети"
var _sent_t = 0.0


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected)
    multiplayer.connection_failed.connect(_on_failed)
    multiplayer.server_disconnected.connect(_on_server_lost)


func _set_status(t):
    status = t
    status_changed.emit(t)


func _my_info():
    return {"nick": AccountSystem.current_nick, "admin": AccountSystem.is_admin}


func host(port = DEFAULT_PORT, dedicated = false):
    leave()
    var peer = ENetMultiplayerPeer.new()
    var err = peer.create_server(int(port), 32)
    if err != OK:
        _set_status("Не удалось запустить сервер (порт занят?)")
        return false
    multiplayer.multiplayer_peer = peer
    is_online = true
    is_server = true
    server_only = dedicated
    roster = {}
    if not dedicated:
        roster[1] = _my_info()
    _set_status("Сервер запущен, порт %d. Игроков: %d" % [int(port), roster.size()])
    roster_changed.emit()
    return true


func join(address, port = DEFAULT_PORT):
    leave()
    var peer = ENetMultiplayerPeer.new()
    var err = peer.create_client(address.strip_edges(), int(port))
    if err != OK:
        _set_status("Не удалось начать подключение")
        return false
    multiplayer.multiplayer_peer = peer
    is_server = false
    _set_status("Подключение к %s:%d ..." % [address, int(port)])
    return true


func leave():
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer.close()
        multiplayer.multiplayer_peer = null
    for id in roster.keys():
        peer_left.emit(id)
    roster = {}
    is_online = false
    is_server = false
    server_only = false
    _set_status("Не в сети")
    roster_changed.emit()


func local_ip():
    for a in IP.get_local_addresses():
        if a.count(".") == 3 and not a.begins_with("127.") and not a.begins_with("169."):
            return a
    return "?"


# ---------- события соединения ----------
func _on_connected():
    is_online = true
    _set_status("Подключено. Регистрация на сервере...")
    rpc_id(1, "srv_register", AccountSystem.current_nick, AccountSystem.ADMIN_HASH if AccountSystem.is_admin else "", PROTOCOL)


func _on_failed():
    multiplayer.multiplayer_peer = null
    is_online = false
    _set_status("Не удалось подключиться (проверьте адрес и порт)")


func _on_server_lost():
    multiplayer.multiplayer_peer = null
    for id in roster.keys():
        peer_left.emit(id)
    roster = {}
    is_online = false
    _set_status("Соединение с сервером потеряно")
    roster_changed.emit()


func _on_peer_disconnected(id):
    if is_server:
        roster.erase(id)
        rpc("cl_roster", roster)


# ---------- RPC ----------
@rpc("any_peer", "call_remote", "reliable")
func srv_register(nick, proof, proto):
    if not is_server:
        return
    var id = multiplayer.get_remote_sender_id()
    nick = str(nick).strip_edges().substr(0, 16)
    if int(proto) != PROTOCOL:
        rpc_id(id, "cl_reject", "Версии игры не совпадают")
        multiplayer.multiplayer_peer.disconnect_peer(id)
        return
    for k in roster:
        if str(roster[k].nick).to_upper() == nick.to_upper():
            rpc_id(id, "cl_reject", "Этот ник уже в сети")
            multiplayer.multiplayer_peer.disconnect_peer(id)
            return
    roster[id] = {"nick": nick, "admin": str(proof) == AccountSystem.ADMIN_HASH and nick.to_upper() == AccountSystem.ADMIN_NICK}
    rpc("cl_roster", roster)


@rpc("authority", "call_local", "reliable")
func cl_roster(r):
    for id in roster.keys():
        if not r.has(id):
            peer_left.emit(id)
    roster = r
    if not is_server:
        is_online = true
        _set_status("В сети. Игроков: %d" % roster.size())
    else:
        _set_status("Сервер: игроков %d" % roster.size())
    roster_changed.emit()


@rpc("authority", "call_remote", "reliable")
func cl_reject(reason):
    leave()
    _set_status("Отказ сервера: " + str(reason))


@rpc("any_peer", "call_local", "reliable")
func chat(text):
    var id = multiplayer.get_remote_sender_id()
    if id == 0:
        id = multiplayer.get_unique_id()
    var info = roster.get(id, {"nick": "?", "admin": false})
    chat_received.emit(info.nick, str(text).substr(0, 140), info.admin)


func send_chat(text):
    if is_online and multiplayer.multiplayer_peer != null and text.strip_edges() != "":
        rpc("chat", text.strip_edges())


@rpc("any_peer", "call_remote", "unreliable")
func state(pos, yaw, anim, hat):
    var id = multiplayer.get_remote_sender_id()
    var info = roster.get(id, null)
    if info == null:
        return
    remote_state.emit(id, pos, yaw, anim, hat, info.nick)


@rpc("any_peer", "call_remote", "reliable")
func srv_admin(cmd, arg):
    if not is_server:
        return
    var id = multiplayer.get_remote_sender_id()
    if not roster.get(id, {}).get("admin", false):
        return
    match cmd:
        "kick":
            var target = int(arg)
            if target != 1 and roster.has(target):
                multiplayer.multiplayer_peer.disconnect_peer(target)
        "announce":
            rpc("cl_announce", str(arg).substr(0, 140))


@rpc("authority", "call_local", "reliable")
func cl_announce(text):
    announcement.emit(str(text))


# Вызывает администратор (в том числе хост)
func admin_command(cmd, arg):
    if not is_online or not AccountSystem.is_admin:
        return
    if is_server:
        var tmp = {"kick": cmd == "kick", "announce": cmd == "announce"}
        if cmd == "kick" and int(arg) != 1 and roster.has(int(arg)):
            multiplayer.multiplayer_peer.disconnect_peer(int(arg))
        elif cmd == "announce":
            rpc("cl_announce", str(arg).substr(0, 140))
    else:
        rpc_id(1, "srv_admin", cmd, arg)


func _process(delta):
    if not is_online or server_only or multiplayer.multiplayer_peer == null:
        return
    _sent_t += delta
    if _sent_t < 0.07:
        return
    _sent_t = 0.0
    var pl = GameState.player_node
    if pl == null or GameState.in_menu or multiplayer.get_peers().is_empty():
        return
    rpc("state", pl.global_position, pl.vis.rotation.y, pl.anim_state, GameState.cosmetic)
