extends Node
## Сохранение в user://save_<логин>.json (с резервной копией): отдельный файл на каждый аккаунт.
## Автосохранение каждые 30 с, при сворачивании и выходе. Без входа в аккаунт ничего не сохраняется.

var _timer = 0.0


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS


func _path():
    return AccountSystem.save_path()


func _bak():
    return AccountSystem.save_path() + ".bak"


func has_save():
    return AccountSystem.current_login != "" and (FileAccess.file_exists(_path()) or FileAccess.file_exists(_bak()))


func save_game():
    if AccountSystem.current_login == "":
        return false
    var data = GameState.to_dict()
    data["version"] = 2
    if FileAccess.file_exists(_path()):
        DirAccess.copy_absolute(_path(), _bak())
    var f = FileAccess.open(_path(), FileAccess.WRITE)
    if f == null:
        push_warning("Не удалось открыть файл сохранения")
        return false
    f.store_string(JSON.stringify(data))
    f.close()
    return true


func load_game():
    if AccountSystem.current_login == "":
        return false
    for path in [_path(), _bak()]:
        if FileAccess.file_exists(path):
            var f = FileAccess.open(path, FileAccess.READ)
            if f == null:
                continue
            var parsed = JSON.parse_string(f.get_as_text())
            f.close()
            if typeof(parsed) == TYPE_DICTIONARY:
                GameState.from_dict(parsed)
                return true
    GameState.new_game()
    return false


func _process(delta):
    _timer += delta
    if _timer > 30.0:
        _timer = 0.0
        if not GameState.in_menu:
            save_game()


func _notification(what):
    if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if not GameState.in_menu:
            save_game()
