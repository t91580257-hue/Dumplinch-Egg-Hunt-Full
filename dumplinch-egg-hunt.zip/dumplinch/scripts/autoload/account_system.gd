extends Node
## Аккаунты: ник, логин, пароль (хранится только хеш с индивидуальной солью), отдельное сохранение на аккаунт.
## ВНИМАНИЕ: проверка выполняется на устройстве. Это защита от случайного доступа, а не от взлома клиента:
## для настоящей защиты админ-прав нужен серверный аккаунт (см. README).

signal logged_in
const PATH = "user://accounts.json"
const LEGACY_SAVE = "user://dumplinch_save.json"
const SALT = "dumplinch-egg-hunt-v2"
const ADMIN_NICK = "DUMPLINCH"
const ADMIN_HASH = "e01192872117e93addbaf7a43f2810e7c49c0496cc8113030a5f2bfb3d776cdc"

var accounts = {}
var current_login = ""
var current_nick = ""
var is_admin = false
var last_login = ""


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    _load()


func _load():
    if not FileAccess.file_exists(PATH):
        return
    var f = FileAccess.open(PATH, FileAccess.READ)
    if f == null:
        return
    var d = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(d) == TYPE_DICTIONARY:
        accounts = d.get("accounts", {})
        last_login = str(d.get("last_login", ""))


func _save():
    var f = FileAccess.open(PATH, FileAccess.WRITE)
    if f == null:
        return
    f.store_string(JSON.stringify({"accounts": accounts, "last_login": last_login}))
    f.close()


func _hash(salt, login, pw):
    return ("%s:%s:%s" % [salt, login, pw]).sha256_text()


func admin_check(nick, pw):
    return nick.to_upper() == ADMIN_NICK and ("%s:%s:%s" % [SALT, ADMIN_NICK, pw]).sha256_text() == ADMIN_HASH


func save_path():
    return "user://save_%s.json" % current_login


func valid_nick(n):
    var re = RegEx.new()
    re.compile("^[\\p{L}0-9_ -]{3,16}$")
    return re.search(n) != null


func valid_login(l):
    var re = RegEx.new()
    re.compile("^[a-z0-9_]{3,20}$")
    return re.search(l) != null


# Возвращает текст ошибки или пустую строку при успехе
func register(nick, login, pw, pw2):
    nick = nick.strip_edges()
    login = login.strip_edges().to_lower()
    if not valid_nick(nick):
        return "Ник: 3-16 символов (буквы, цифры, пробел, _ и -)"
    if not valid_login(login):
        return "Логин: 3-20 символов, только a-z, 0-9 и _"
    if pw.length() < 6:
        return "Пароль: минимум 6 символов"
    if pw != pw2:
        return "Пароли не совпадают"
    if accounts.has(login):
        return "Такой логин уже занят"
    if nick.to_upper() == ADMIN_NICK and not admin_check(nick, pw):
        return "Этот ник зарезервирован"
    for k in accounts:
        if str(accounts[k].nick).to_upper() == nick.to_upper():
            return "Такой ник уже занят"
    var salt = str(randi()) + str(Time.get_ticks_usec())
    accounts[login] = {"nick": nick, "salt": salt, "hash": _hash(salt, login, pw), "created": int(Time.get_unix_time_from_system())}
    # прогресс из старой версии игры достаётся первому созданному аккаунту
    if accounts.size() == 1 and FileAccess.file_exists(LEGACY_SAVE):
        DirAccess.copy_absolute(LEGACY_SAVE, "user://save_%s.json" % login)
    _save()
    return _enter(login, admin_check(nick, pw))


func login(login, pw):
    login = login.strip_edges().to_lower()
    if not accounts.has(login):
        return "Аккаунт не найден"
    var a = accounts[login]
    if _hash(a.salt, login, pw) != a.hash:
        return "Неверный пароль"
    return _enter(login, admin_check(a.nick, pw))


func _enter(login, admin):
    current_login = login
    current_nick = accounts[login].nick
    is_admin = admin
    last_login = login
    _save()
    GameState.god = false
    GameState.fly = false
    GameState.admin_speed = 1.0
    GameState.admin_dmg = 1.0
    GameState.no_cd = false
    SaveSystem.load_game()
    logged_in.emit()
    return ""


func logout():
    SaveSystem.save_game()
    current_login = ""
    current_nick = ""
    is_admin = false
    GameState.new_game()
    NetworkManager.leave()
