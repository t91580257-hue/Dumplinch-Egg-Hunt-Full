extends "res://scripts/ui/window_base.gd"
## Награды из сундука: подсветка редкости, особый блок для уникального яйца.

var result = {}


func _init():
    super("Награда")


func show_rewards(res):
    result = res
    open()


func build(box):
    if result.is_empty():
        return
    var cd = GameData.CHESTS[result.ctype]
    box.add_child(UIF.label(cd.name + " открыт!", 32, cd.glow))
    if result.unique != null:
        var u = result.unique
        var v = UIF.card(box, Color(0.32, 0.22, 0.04, 0.97))
        v.add_child(UIF.label("УНИКАЛЬНОЕ ЯЙЦО!", 32, Color("ffe070")))
        v.add_child(UIF.label(u.name, 28, u.accent.lightened(0.3)))
        v.add_child(UIF.label(u.desc, 20, Color(0.9, 0.9, 1.0), true))
        v.add_child(UIF.label("%s. Шанс из этого сундука: %.2f%%" % [GameData.tier_name(u.tier), GameState.unique_chance_percent(result.ctype, u.id)], 18, Color(0.85, 0.9, 1.0), true))
        v.add_child(UIF.label("Яйцо лежит в инвентаре. Откройте его, когда будете готовы.", 18, Color(0.85, 0.9, 1.0), true))
    if result.get("special") != null:
        var sp = result.special
        var v3 = UIF.card(box, Color(0.3, 0.12, 0.3, 0.97))
        v3.add_child(UIF.label("ОСОБОЕ ЯЙЦО!", 32, Color("ff9ed0")))
        v3.add_child(UIF.label(sp.name, 28, sp.accent.lightened(0.3)))
        v3.add_child(UIF.label(sp.desc + " Внутри Химик или Милик (по 400 силы).", 20, Color(0.95, 0.9, 1.0), true))
        v3.add_child(UIF.label("Выпадает только из секретных сундуков (шанс 10% при каждом открытии).", 18, Color(0.85, 0.9, 1.0), true))
    for r in result.rewards:
        if r.text.begins_with("УНИКАЛЬНОЕ") or r.text.begins_with("ОСОБОЕ"):
            continue
        var v2 = UIF.card(box, Color(0.12, 0.15, 0.3, 0.95))
        v2.add_child(UIF.label(r.text, 24, r.color.lightened(0.25)))
