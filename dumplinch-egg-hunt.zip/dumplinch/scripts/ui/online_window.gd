extends "res://scripts/ui/window_base.gd"
## Онлайн: подключение к серверу, создание сервера на этом устройстве, список игроков.

var addr_in
var port_in
var host_port_in
var last_addr = "127.0.0.1"


func _init():
    super("Онлайн")


func _ready():
    NetworkManager.status_changed.connect(func(_t): _soft_refresh())
    NetworkManager.roster_changed.connect(_soft_refresh)


func _soft_refresh():
    if visible:
        refresh_all()


func _line(box, ph, text):
    var e = LineEdit.new()
    e.placeholder_text = ph
    e.text = text
    e.custom_minimum_size = Vector2(0, 56)
    e.add_theme_font_size_override("font_size", 22)
    box.add_child(e)
    return e


func _join():
    last_addr = addr_in.text
    NetworkManager.join(addr_in.text, int(port_in.text) if port_in.text.is_valid_int() else NetworkManager.DEFAULT_PORT)


func _host():
    NetworkManager.host(int(host_port_in.text) if host_port_in.text.is_valid_int() else NetworkManager.DEFAULT_PORT, false)


func _leave():
    NetworkManager.leave()


func build(box):
    box.add_child(UIF.label("Статус: " + NetworkManager.status, 24, Color("ffd24a"), true))
    if NetworkManager.is_online:
        box.add_child(UIF.label("Игроки в сети:", 26, Color("ffd24a")))
        for id in NetworkManager.roster:
            var info = NetworkManager.roster[id]
            box.add_child(UIF.label("%s%s%s" % [info.nick, "  [АДМИН]" if info.admin else "", "  (вы)" if id == multiplayer.get_unique_id() else ""], 22))
        if NetworkManager.is_server:
            box.add_child(UIF.label("Ваш адрес в локальной сети: %s, порт UDP %d. Для игры через интернет пробросьте этот порт на роутере или запустите выделенный сервер." % [NetworkManager.local_ip(), NetworkManager.DEFAULT_PORT], 18, Color(0.85, 0.9, 1.0), true))
        var b = UIF.button("Отключиться", Vector2(0, 60), 24)
        b.pressed.connect(_leave)
        box.add_child(b)
        box.add_child(UIF.label("Кнопка чата появляется на экране игры. Вы видите других игроков в мире, но бои, враги и сундуки у каждого свои.", 18, Color(0.85, 0.9, 1.0), true))
        return
    var v = UIF.card(box)
    v.add_child(UIF.label("Подключиться к серверу", 26, Color("ffd24a")))
    addr_in = _line(v, "Адрес (IP или имя)", last_addr)
    port_in = _line(v, "Порт", str(NetworkManager.DEFAULT_PORT))
    var bj = UIF.button("Подключиться", Vector2(0, 60), 24)
    bj.pressed.connect(_join)
    v.add_child(bj)
    var v2 = UIF.card(box)
    v2.add_child(UIF.label("Создать сервер на этом устройстве", 26, Color("ffd24a")))
    v2.add_child(UIF.label("Другие игроки подключатся по вашему IP (%s в этой сети). Нужен открытый UDP-порт." % NetworkManager.local_ip(), 18, Color(0.85, 0.9, 1.0), true))
    host_port_in = _line(v2, "Порт", str(NetworkManager.DEFAULT_PORT))
    var bh = UIF.button("Запустить сервер", Vector2(0, 60), 24)
    bh.pressed.connect(_host)
    v2.add_child(bh)
    box.add_child(UIF.label("Важно: ваш аккаунт нужен для входа, ник отображается над героем. Игра по сети экспериментальная.", 18, Color(0.85, 0.9, 1.0), true))
