extends "res://scripts/ui/window_base.gd"
## Карта открытого мира и телепорт между активированными точками.

const MiniMap = preload("res://scripts/ui/minimap.gd")


func _init():
    super("Карта мира")


func _teleport(i):
    var pl = GameState.player_node
    if pl == null or pl.dead:
        return
    close()
    var dest = GameData.region_origin(i) + Vector3(0, 2.0, 20)
    pl.global_position = dest
    pl.velocity = Vector3.ZERO
    GameState.screen_flash.emit(Color(0.5, 0.9, 1.0, 0.7), 0.6)
    AudioManager.play_sfx("whoosh", 1.5)
    GameState.message.emit("Телепорт: " + GameData.REGIONS[i].name)


func build(box):
    box.add_child(UIF.label("Регион: %s     Открыто регионов: %d / 5" % [GameData.REGIONS[GameState.current_region].name, GameState.discovered_regions.size()], 22, Color("ffd24a")))
    var m = MiniMap.new(true)
    m.custom_minimum_size = Vector2(0, 430)
    m.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    m.process_mode = Node.PROCESS_MODE_ALWAYS
    box.add_child(m)
    box.add_child(UIF.label("Телепорт (активируйте точку, подойдя к синему столбу света в регионе):", 20, Color(0.85, 0.9, 1.0), true))
    var r = UIF.row(box)
    for i in 5:
        var b = UIF.button(GameData.REGIONS[i].name, Vector2(0, 56), 18)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.disabled = not GameState.waypoints.has(i)
        b.pressed.connect(_teleport.bind(i))
        r.add_child(b)
    box.add_child(UIF.label("Рекомендуемые уровни: " + ", ".join(GameData.REGIONS.map(func(x): return "%s - %d" % [x.name, x.level])), 17, Color(0.8, 0.85, 1.0), true))
