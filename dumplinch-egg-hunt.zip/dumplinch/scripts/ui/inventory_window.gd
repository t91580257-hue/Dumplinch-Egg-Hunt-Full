extends "res://scripts/ui/window_base.gd"
## Инвентарь: вкладки «Яйца и предметы» и «Сундуки». Сундуки и яйца открываются только по кнопке.

const Icon = preload("res://scripts/ui/icon.gd")
var tab = "items"


func _init():
    super("Инвентарь")


func _set_tab(t):
    tab = t
    refresh_all()


func build(box):
    box.add_child(UIF.currency_bar())
    var total_chests = 0
    for k in GameState.chests:
        total_chests += GameState.chests[k]
    var tabs = UIF.row(box)
    for t in [["items", "Яйца и предметы"], ["chests", "Сундуки (%d)" % total_chests]]:
        var b = UIF.button(t[1], Vector2(0, 56), 22)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.disabled = (tab == t[0])
        b.pressed.connect(_set_tab.bind(t[0]))
        tabs.add_child(b)
    if tab == "chests":
        _chests(box)
    else:
        _items(box)


func _chests(box):
    box.add_child(UIF.label("Сундуки не открываются сами: откройте их, когда захотите.", 18, Color(0.8, 0.85, 1.0), true))
    for ctype in GameData.CHEST_ORDER:
        var cd = GameData.CHESTS[ctype]
        var n = GameState.chests.get(ctype, 0)
        var v = UIF.card(box, Color(0.12, 0.15, 0.3, 0.9) if n > 0 else Color(0.08, 0.1, 0.2, 0.7))
        var r = UIF.row(v)
        r.add_child(Icon.new("bag", 44))
        var l = UIF.label("%s  x%d" % [cd.name, n], 26, cd.color.lightened(0.3) if n > 0 else Color(0.6, 0.6, 0.7))
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        r.add_child(l)
        var b = UIF.button("Открыть", Vector2(170, 56))
        b.disabled = n <= 0
        b.pressed.connect(_open_chest.bind(ctype))
        r.add_child(b)
        v.add_child(UIF.label(cd.desc + "  Шанс уникального яйца: %.0f%%." % (cd.unique[0] * 100.0), 17, Color(0.8, 0.85, 1.0), true))


func _items(box):
    box.add_child(UIF.label("Яйца", 28, Color("ffd24a")))
    var any = false
    for egg in GameData.EGGS + GameData.UNIQUE_EGGS:
        var n = GameState.eggs.get(egg.id, 0)
        if n <= 0:
            continue
        any = true
        var uniq = egg.get("unique", false)
        var v = UIF.card(box, Color(0.28, 0.2, 0.06, 0.95) if uniq else Color(0.12, 0.15, 0.3, 0.9))
        var r = UIF.row(v)
        r.add_child(Icon.new("egg", 44))
        var l = UIF.label("%s  x%d" % [egg.name, n], 24, egg.color.lightened(0.35))
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        r.add_child(l)
        var b1 = UIF.button("Открыть", Vector2(150, 56))
        b1.pressed.connect(_open_egg.bind(egg.id, 1))
        r.add_child(b1)
        if n >= 2:
            var cnt = mini(n, 10)
            var b2 = UIF.button("Открыть x%d" % cnt, Vector2(190, 56))
            b2.pressed.connect(_open_egg.bind(egg.id, cnt))
            r.add_child(b2)
        if uniq:
            v.add_child(UIF.label("Уникальное: %s. %s" % [GameData.tier_name(egg.tier), egg.desc], 17, Color("ffe9a0"), true))
    if not any:
        box.add_child(UIF.label("Яиц нет. Найдите их в мире (кнопка действия рядом с яйцом), купите в магазине или найдите сундуки.", 20, Color(0.8, 0.85, 1.0), true))
    box.add_child(UIF.label("Ускорители", 28, Color("ffd24a")))
    var names = {"coins": "x2 монеты", "xp": "x2 опыт"}
    var any_b = false
    for k in GameState.boosters:
        if GameState.boosters[k] > 0.0:
            any_b = true
            var s = int(GameState.boosters[k])
            box.add_child(UIF.label("%s: осталось %d:%02d" % [names[k], s / 60, s % 60], 22))
    if not any_b:
        box.add_child(UIF.label("Нет активных ускорителей.", 20, Color(0.8, 0.85, 1.0)))
    box.add_child(UIF.label("Шапка героя", 28, Color("ffd24a")))
    var r2 = UIF.row(box)
    for key in GameState.cosmetics_owned:
        if GameData.COSMETICS.has(key):
            var b = UIF.button(GameData.COSMETICS[key].name, Vector2(0, 56), 20)
            b.disabled = (GameState.cosmetic == key)
            b.pressed.connect(_equip_cosmetic.bind(key))
            r2.add_child(b)


func _open_egg(id, n):
    GameState.request_open_egg.emit(id, n)


func _open_chest(ctype):
    GameState.request_open_chest.emit(ctype)


func _equip_cosmetic(key):
    GameState.cosmetic = key
    GameState.settings_changed.emit()
    refresh_all()
