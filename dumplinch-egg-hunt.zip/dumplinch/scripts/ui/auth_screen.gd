extends Control
## Вход и регистрация: ник, логин, пароль. Раскладка по координатам (без якорей).

const UIF = preload("res://scripts/ui/ui_factory.gd")
signal done
var mode = "login"
var box
var nick_in
var login_in
var pw_in
var pw2_in
var err_label
var title_label
var action_btn
var switch_btn
var dim
var center
var _vp = Vector2.ZERO


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    dim = ColorRect.new()
    dim.color = Color(0.03, 0.05, 0.12, 0.8)
    add_child(dim)
    center = CenterContainer.new()
    add_child(center)
    var panel = PanelContainer.new()
    center.add_child(panel)
    box = VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    box.custom_minimum_size = Vector2(520, 0)
    panel.add_child(box)
    title_label = UIF.label("", 38, Color("ffd24a"))
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(title_label)
    nick_in = _field("Ник (виден другим игрокам)", false)
    login_in = _field("Логин (a-z, 0-9, _)", false)
    pw_in = _field("Пароль", true)
    pw2_in = _field("Повторите пароль", true)
    err_label = UIF.label("", 20, Color("ff7a7a"), true)
    box.add_child(err_label)
    action_btn = UIF.button("", Vector2(0, 64), 26)
    action_btn.pressed.connect(_submit)
    box.add_child(action_btn)
    switch_btn = UIF.button("", Vector2(0, 52), 20)
    switch_btn.pressed.connect(_switch)
    box.add_child(switch_btn)
    _apply()
    _fit()


func _field(ph, secret):
    var e = LineEdit.new()
    e.placeholder_text = ph
    e.secret = secret
    e.custom_minimum_size = Vector2(0, 58)
    e.add_theme_font_size_override("font_size", 24)
    e.max_length = 32
    box.add_child(e)
    return e


func reset():
    err_label.text = ""
    pw_in.text = ""
    pw2_in.text = ""
    if AccountSystem.last_login != "" and AccountSystem.accounts.has(AccountSystem.last_login):
        mode = "login"
        login_in.text = AccountSystem.last_login
    elif AccountSystem.accounts.is_empty():
        mode = "register"
    _apply()


func _apply():
    var reg = mode == "register"
    title_label.text = "Регистрация" if reg else "Вход в аккаунт"
    nick_in.visible = reg
    pw2_in.visible = reg
    action_btn.text = "Создать аккаунт" if reg else "Войти"
    switch_btn.text = "Уже есть аккаунт? Войти" if reg else "Нет аккаунта? Зарегистрироваться"
    err_label.text = ""


func _switch():
    mode = "login" if mode == "register" else "register"
    _apply()


func _submit():
    var err = ""
    if mode == "register":
        err = AccountSystem.register(nick_in.text, login_in.text, pw_in.text, pw2_in.text)
    else:
        err = AccountSystem.login(login_in.text, pw_in.text)
    if err != "":
        err_label.text = err
        AudioManager.play_ui("error")
        return
    pw_in.text = ""
    pw2_in.text = ""
    AudioManager.play_ui("reward")
    done.emit()


func _fit():
    _vp = get_viewport_rect().size
    position = Vector2.ZERO
    size = _vp
    dim.position = Vector2.ZERO
    dim.size = _vp
    center.position = Vector2.ZERO
    center.size = _vp


func _process(_d):
    if visible and get_viewport_rect().size != _vp:
        _fit()
