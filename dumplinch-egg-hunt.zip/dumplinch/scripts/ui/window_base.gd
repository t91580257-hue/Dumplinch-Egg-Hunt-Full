extends Control
## Базовое окно: затемнение, панель, заголовок, прокручиваемое содержимое.
## Наследники переопределяют build(box). Любое действие вызывает refresh_all().

const UIF = preload("res://scripts/ui/ui_factory.gd")
signal closed
var title_text = ""
var content
var panel
var dim
var _vp = Vector2.ZERO


func _init(t = ""):
    title_text = t
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false
    dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.6)
    add_child(dim)
    panel = PanelContainer.new()
    add_child(panel)
    var v = VBoxContainer.new()
    v.add_theme_constant_override("separation", 8)
    panel.add_child(v)
    var top = HBoxContainer.new()
    v.add_child(top)
    var tl = UIF.label(t, 32, Color("ffd24a"))
    tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(tl)
    var cb = UIF.button("Закрыть", Vector2(160, 60))
    cb.pressed.connect(close)
    top.add_child(cb)
    var scroll = ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    v.add_child(scroll)
    content = VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 10)
    scroll.add_child(content)


func _fit():
    _vp = get_viewport_rect().size
    position = Vector2.ZERO
    size = _vp
    dim.position = Vector2.ZERO
    dim.size = _vp
    panel.position = Vector2(_vp.x * 0.04, _vp.y * 0.05)
    panel.size = Vector2(_vp.x * 0.92, _vp.y * 0.9)


func _process(_d):
    if visible and get_viewport_rect().size != _vp:
        _fit()


func open():
    _fit()
    refresh_all()
    if not visible:
        visible = true
        GameState.window_opened()


func close():
    if visible:
        visible = false
        GameState.window_closed()
        closed.emit()


func refresh_all():
    for c in content.get_children():
        content.remove_child(c)
        c.queue_free()
    build(content)


func build(_box):
    pass
