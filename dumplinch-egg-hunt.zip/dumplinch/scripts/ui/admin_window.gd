extends "res://scripts/ui/window_base.gd"
## Админ-панель (только для администратора): ресурсы, предметы, игрок, мир, онлайн, команды.
## Работает на устройстве: даёт любые ресурсы и предметы, телепорты, бессмертие, полёт, управление миром.

var tab = "res"
var amount_in
var count_in
var egg_pick
var pet_pick
var chest_pick
var boss_pick
var coords_in
var cmd_in
var ann_in
var log_text = ""


func _init():
    super("Админ-панель")


func _set_tab(t):
    tab = t
    refresh_all()


func _num(e, d = 1000):
    var t = e.text.strip_edges() if e != null else ""
    return int(t) if t.is_valid_int() else d


func _field(box, text, ph = ""):
    var e = LineEdit.new()
    e.text = text
    e.placeholder_text = ph
    e.custom_minimum_size = Vector2(0, 54)
    e.add_theme_font_size_override("font_size", 22)
    box.add_child(e)
    return e


func _btn(parent, text, cb, bind = null):
    var b = UIF.button(text, Vector2(0, 52), 19)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    if bind == null:
        b.pressed.connect(cb)
    else:
        b.pressed.connect(cb.bind(bind))
    parent.add_child(b)
    return b


func _toast(t):
    GameState.message.emit("[Админ] " + t)


func build(box):
    if not AccountSystem.is_admin:
        box.add_child(UIF.label("Доступ запрещён.", 26, Color("ff7a7a")))
        return
    box.add_child(UIF.label("Вы вошли как администратор: %s" % AccountSystem.current_nick, 20, Color("ffd24a")))
    var tabs = UIF.row(box)
    for t in [["res", "Ресурсы"], ["items", "Предметы"], ["player", "Игрок"], ["world", "Мир"], ["online", "Онлайн"], ["cmd", "Команды"]]:
        var b = UIF.button(t[1], Vector2(0, 52), 18)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.disabled = tab == t[0]
        b.pressed.connect(_set_tab.bind(t[0]))
        tabs.add_child(b)
    match tab:
        "res": _tab_res(box)
        "items": _tab_items(box)
        "player": _tab_player(box)
        "world": _tab_world(box)
        "online": _tab_online(box)
        "cmd": _tab_cmd(box)


# ---------- Ресурсы ----------
func _tab_res(box):
    box.add_child(UIF.currency_bar())
    box.add_child(UIF.label("Количество:", 20))
    amount_in = _field(box, "1000")
    var r1 = UIF.row(box)
    _btn(r1, "+ Монеты", _give_cur, "coins")
    _btn(r1, "+ Самоцветы", _give_cur, "gems")
    var r2 = UIF.row(box)
    _btn(r2, "+ Кристаллы", _give_cur, "crystals")
    _btn(r2, "+ Жетоны", _give_cur, "tokens")
    var r3 = UIF.row(box)
    _btn(r3, "+ Опыт", _give_xp)
    _btn(r3, "Уровень = количество", _set_level)
    var r4 = UIF.row(box)
    _btn(r4, "Всё по 1 000 000", _give_all)
    _btn(r4, "Обнулить валюты", _zero_cur)
    var r5 = UIF.row(box)
    _btn(r5, "Полное здоровье", _heal)
    _btn(r5, "Слоты питомцев = 8", _slots)


func _give_cur(k):
    var n = _num(amount_in)
    match k:
        "coins": GameState.coins += n
        "gems": GameState.gems += n
        "crystals": GameState.crystals += n
        "tokens": GameState.tokens += n
    GameState.currency_changed.emit()
    _toast("+%d %s" % [n, k])
    refresh_all()


func _give_xp():
    GameState.gain_xp(_num(amount_in))
    refresh_all()


func _set_level():
    GameState.level = clampi(_num(amount_in, 1), 1, 999)
    GameState.xp = 0
    GameState.hp = GameState.max_hp()
    GameState.stats_changed.emit()
    _toast("Уровень %d" % GameState.level)


func _give_all():
    GameState.coins += 1000000
    GameState.gems += 1000000
    GameState.crystals += 1000000
    GameState.tokens += 1000000
    GameState.currency_changed.emit()
    refresh_all()


func _zero_cur():
    GameState.coins = 0
    GameState.gems = 0
    GameState.crystals = 0
    GameState.tokens = 0
    GameState.currency_changed.emit()
    refresh_all()


func _heal():
    GameState.heal(99999)


func _slots():
    GameState.pet_slots = 8
    GameState.pets_changed.emit()
    _toast("Слотов: 8")


# ---------- Предметы ----------
func _opt(box, label, items):
    var r = UIF.row(box)
    r.add_child(UIF.label(label, 20))
    var ob = OptionButton.new()
    ob.custom_minimum_size = Vector2(0, 54)
    ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    ob.add_theme_font_size_override("font_size", 20)
    for it in items:
        ob.add_item(it)
    r.add_child(ob)
    return ob


func _tab_items(box):
    box.add_child(UIF.label("Количество:", 20))
    count_in = _field(box, "1")
    var eggs = GameData.EGGS + GameData.UNIQUE_EGGS
    egg_pick = _opt(box, "Яйцо:", eggs.map(func(e): return e.name))
    _btn(box, "Выдать яйцо", _give_egg)
    pet_pick = _opt(box, "Питомец:", GameData.PETS.map(func(p): return "%s (%s)" % [p.name, GameData.rarity_name(p.rarity)]))
    _btn(box, "Выдать питомца (x количество)", _give_pet)
    chest_pick = _opt(box, "Сундук:", GameData.CHEST_ORDER.map(func(c): return GameData.CHESTS[c].name))
    _btn(box, "Выдать сундуки", _give_chest)
    var r = UIF.row(box)
    _btn(r, "Всех питомцев", _give_all_pets)
    _btn(r, "Все уникальные яйца", _give_all_unique)
    var r2 = UIF.row(box)
    _btn(r2, "Все шапки", _give_cosm)
    _btn(r2, "Ускорители 1 час", _give_boost)


func _give_egg():
    var eggs = GameData.EGGS + GameData.UNIQUE_EGGS
    var e = eggs[egg_pick.selected]
    GameState.add_egg(e.id, _num(count_in, 1))
    _toast("Яйцо: " + e.name)


func _give_pet():
    var p = GameData.PETS[pet_pick.selected]
    for i in clampi(_num(count_in, 1), 1, 50):
        GameState.add_pet(p.id)
    _toast("Питомец: " + p.name)


func _give_chest():
    var c = GameData.CHEST_ORDER[chest_pick.selected]
    GameState.add_chest(c, _num(count_in, 1))
    _toast("Сундук: " + GameData.CHESTS[c].name)


func _give_all_pets():
    for p in GameData.PETS:
        GameState.add_pet(p.id)
    _toast("Выданы все питомцы")


func _give_all_unique():
    for e in GameData.UNIQUE_EGGS:
        GameState.add_egg(e.id, 1)
        if not GameState.discovered_eggs.has(e.id):
            GameState.discovered_eggs.append(e.id)
    GameState._check_all()
    _toast("Выданы все уникальные яйца")


func _give_cosm():
    for k in GameData.COSMETICS:
        if not GameState.cosmetics_owned.has(k):
            GameState.cosmetics_owned.append(k)
    _toast("Все шапки открыты")


func _give_boost():
    GameState.boosters["coins"] = 3600.0
    GameState.boosters["xp"] = 3600.0
    GameState.currency_changed.emit()


# ---------- Игрок ----------
func _check(box, text, key, on):
    var c = CheckButton.new()
    c.text = text
    c.button_pressed = on
    c.focus_mode = Control.FOCUS_NONE
    c.custom_minimum_size = Vector2(0, 54)
    c.add_theme_font_size_override("font_size", 22)
    c.toggled.connect(_on_check.bind(key))
    box.add_child(c)


func _on_check(v, key):
    match key:
        "god": GameState.god = v
        "fly": GameState.fly = v
        "nocd": GameState.no_cd = v
    _toast("%s: %s" % [key, "вкл" if v else "выкл"])


func _slider(box, text, lo, hi, val, key):
    var r = UIF.row(box)
    var l = UIF.label(text, 20)
    l.custom_minimum_size = Vector2(260, 0)
    r.add_child(l)
    var s = HSlider.new()
    s.min_value = lo
    s.max_value = hi
    s.step = 0.5
    s.value = val
    s.custom_minimum_size = Vector2(300, 44)
    s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    s.value_changed.connect(_on_slider.bind(key))
    r.add_child(s)


func _on_slider(v, key):
    match key:
        "speed": GameState.admin_speed = v
        "dmg": GameState.admin_dmg = v
        "time":
            get_tree().call_group("world", "admin_set_time", v)


func _tab_player(box):
    _check(box, "Бессмертие", "god", GameState.god)
    _check(box, "Полёт и прохождение сквозь стены (прыжок - вверх, уклонение - вниз)", "fly", GameState.fly)
    _check(box, "Без перезарядок", "nocd", GameState.no_cd)
    _slider(box, "Скорость x", 1.0, 10.0, GameState.admin_speed, "speed")
    _slider(box, "Урон x", 1.0, 500.0, GameState.admin_dmg, "dmg")
    box.add_child(UIF.label("Телепорт в регион:", 22, Color("ffd24a")))
    var r = UIF.row(box)
    for i in 5:
        _btn(r, GameData.REGIONS[i].name, _tp_region, i)
    coords_in = _field(box, "", "x z   (например: 120 -300)")
    _btn(box, "Телепорт по координатам", _tp_coords)
    _btn(box, "Открыть все регионы и точки телепорта", _reveal_all)


func _tp_region(i):
    var pl = GameState.player_node
    if pl != null:
        pl.global_position = GameData.region_origin(i) + Vector3(0, 3, 20)
        pl.velocity = Vector3.ZERO
        _toast("Телепорт: " + GameData.REGIONS[i].name)


func _tp_coords():
    var parts = coords_in.text.strip_edges().split(" ", false)
    var pl = GameState.player_node
    if parts.size() >= 2 and pl != null and parts[0].is_valid_float() and parts[1].is_valid_float():
        pl.global_position = Vector3(float(parts[0]), 5.0, float(parts[1]))
        pl.velocity = Vector3.ZERO
        _toast("Телепорт")


func _reveal_all():
    for i in 5:
        if not GameState.discovered_regions.has(i):
            GameState.discovered_regions.append(i)
        if not GameState.waypoints.has(i):
            GameState.waypoints.append(i)
    GameState._check_all()
    _toast("Все регионы открыты")


# ---------- Мир ----------
func _tab_world(box):
    _slider(box, "Время суток (0-1)", 0.0, 1.0, 0.3, "time")
    var rt = UIF.row(box)
    _btn(rt, "Утро", _set_time, 0.02)
    _btn(rt, "День", _set_time, 0.25)
    _btn(rt, "Вечер", _set_time, 0.48)
    _btn(rt, "Ночь", _set_time, 0.75)
    boss_pick = _opt(box, "Босс:", GameData.BOSSES.map(func(b): return b.name))
    _btn(box, "Призвать босса рядом", _spawn_boss)
    var r = UIF.row(box)
    _btn(r, "Призвать 10 врагов", _spawn_enemies)
    _btn(r, "Убить всех врагов и боссов", _kill_all)
    var r2 = UIF.row(box)
    _btn(r2, "Сбросить возрождение сундуков", _reset_chests)
    _btn(r2, "Сбросить побеждённых боссов", _reset_bosses)
    _btn(box, "Сохранить игру сейчас", _save_now)


func _set_time(t):
    get_tree().call_group("world", "admin_set_time", t)


func _spawn_boss():
    get_tree().call_group("world", "admin_spawn_boss", GameData.BOSSES[boss_pick.selected].id)
    _toast("Босс призван")


func _spawn_enemies():
    get_tree().call_group("world", "admin_spawn_enemies", 10)


func _kill_all():
    get_tree().call_group("world", "admin_kill_all")
    _toast("Все враги уничтожены")


func _reset_chests():
    GameState.chest_respawn.clear()
    _toast("Сундуки появятся снова после перезахода в мир")


func _reset_bosses():
    GameState.defeated_bosses.clear()
    _toast("Боссы сброшены (появятся после перезапуска сцены)")


func _save_now():
    SaveSystem.save_game()
    _toast("Сохранено")


# ---------- Онлайн ----------
func _tab_online(box):
    box.add_child(UIF.label("Статус: " + NetworkManager.status, 22, Color("ffd24a"), true))
    if not NetworkManager.is_online:
        box.add_child(UIF.label("Нет подключения. Создайте или найдите сервер в окне «Онлайн».", 20, Color(0.85, 0.9, 1.0), true))
        return
    for id in NetworkManager.roster:
        var info = NetworkManager.roster[id]
        var r = UIF.row(box)
        var l = UIF.label("%s%s  (id %d)" % [info.nick, "  [АДМИН]" if info.admin else "", id], 22)
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        r.add_child(l)
        if id != multiplayer.get_unique_id() and id != 1:
            var b = UIF.button("Кик", Vector2(120, 52), 20)
            b.pressed.connect(_kick.bind(id))
            r.add_child(b)
    ann_in = _field(box, "", "Объявление для всех игроков")
    _btn(box, "Отправить объявление", _announce)


func _kick(id):
    NetworkManager.admin_command("kick", id)
    refresh_all.call_deferred()


func _announce():
    NetworkManager.admin_command("announce", ann_in.text)


# ---------- Консоль команд ----------
func _tab_cmd(box):
    box.add_child(UIF.label("Команды: give coins|gems|crystals|tokens N, level N, xp N, egg ID N, pet ID, chest ТИП N, tp X Z, region N, god, fly, nocd, speed N, dmg N, time 0-1, boss ID, enemies N, killall, heal, say ТЕКСТ", 17, Color(0.85, 0.9, 1.0), true))
    cmd_in = _field(box, "", "Введите команду")
    cmd_in.text_submitted.connect(func(_t): _run())
    _btn(box, "Выполнить", _run)
    box.add_child(UIF.label(log_text, 18, Color("9fffa0"), true))


func _run():
    var res = run_command(cmd_in.text)
    log_text = "> %s\n%s\n%s" % [cmd_in.text, res, log_text.substr(0, 600)]
    cmd_in.text = ""
    refresh_all()


func run_command(line):
    var p = line.strip_edges().split(" ", false)
    if p.is_empty():
        return "пусто"
    var c = p[0].to_lower()
    var a1 = p[1] if p.size() > 1 else ""
    var a2 = p[2] if p.size() > 2 else ""
    match c:
        "give":
            var n = int(a2) if a2.is_valid_int() else 1000
            match a1:
                "coins": GameState.coins += n
                "gems": GameState.gems += n
                "crystals": GameState.crystals += n
                "tokens": GameState.tokens += n
                _: return "give: coins|gems|crystals|tokens N"
            GameState.currency_changed.emit()
            return "ок"
        "level":
            GameState.level = clampi(int(a1), 1, 999)
            GameState.hp = GameState.max_hp()
            GameState.stats_changed.emit()
            return "ок"
        "xp":
            GameState.gain_xp(int(a1))
            return "ок"
        "egg":
            if GameData._egg_idx.has(a1):
                GameState.add_egg(a1, int(a2) if a2.is_valid_int() else 1)
                return "ок"
            return "нет такого яйца: " + a1
        "pet":
            if GameData._pet_idx.has(a1):
                GameState.add_pet(a1)
                return "ок"
            return "нет такого питомца (id вида pet_12)"
        "chest":
            if GameData.CHESTS.has(a1):
                GameState.add_chest(a1, int(a2) if a2.is_valid_int() else 1)
                return "ок"
            return "типы: " + ", ".join(GameData.CHEST_ORDER)
        "tp":
            var pl = GameState.player_node
            if pl != null and a1.is_valid_float() and a2.is_valid_float():
                pl.global_position = Vector3(float(a1), 5.0, float(a2))
                return "ок"
            return "tp X Z"
        "region":
            _tp_region(clampi(int(a1), 0, 4))
            return "ок"
        "god":
            GameState.god = not GameState.god
            return "бессмертие: " + str(GameState.god)
        "fly":
            GameState.fly = not GameState.fly
            return "полёт: " + str(GameState.fly)
        "nocd":
            GameState.no_cd = not GameState.no_cd
            return "без перезарядок: " + str(GameState.no_cd)
        "speed":
            GameState.admin_speed = clampf(float(a1), 0.1, 20.0)
            return "ок"
        "dmg":
            GameState.admin_dmg = clampf(float(a1), 0.1, 100000.0)
            return "ок"
        "time":
            get_tree().call_group("world", "admin_set_time", clampf(float(a1), 0.0, 1.0))
            return "ок"
        "boss":
            get_tree().call_group("world", "admin_spawn_boss", a1)
            return "ок"
        "enemies":
            get_tree().call_group("world", "admin_spawn_enemies", clampi(int(a1) if a1.is_valid_int() else 10, 1, 60))
            return "ок"
        "killall":
            get_tree().call_group("world", "admin_kill_all")
            return "ок"
        "heal":
            GameState.heal(99999)
            return "ок"
        "say":
            NetworkManager.admin_command("announce", line.substr(4))
            return "отправлено"
    return "неизвестная команда"
