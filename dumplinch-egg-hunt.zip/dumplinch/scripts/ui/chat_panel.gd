extends Control
## Мини-чат: последние сообщения слева, кнопка «Чат» открывает ввод. Виден только в онлайне.

const UIF = preload("res://scripts/ui/ui_factory.gd")
var log_box
var input_row
var input
var lines = []


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    var v = VBoxContainer.new()
    v.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v.custom_minimum_size = Vector2(430, 0)
    add_child(v)
    log_box = VBoxContainer.new()
    log_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v.add_child(log_box)
    input_row = HBoxContainer.new()
    input_row.visible = false
    v.add_child(input_row)
    input = LineEdit.new()
    input.placeholder_text = "Сообщение"
    input.custom_minimum_size = Vector2(300, 54)
    input.max_length = 120
    input.add_theme_font_size_override("font_size", 22)
    input.text_submitted.connect(func(_t): _send())
    input_row.add_child(input)
    var sb = UIF.button("OK", Vector2(80, 54), 20)
    sb.pressed.connect(_send)
    input_row.add_child(sb)
    var tb = UIF.button("Чат", Vector2(110, 54), 20)
    tb.pressed.connect(func(): input_row.visible = not input_row.visible)
    v.add_child(tb)
    NetworkManager.chat_received.connect(_on_chat)
    NetworkManager.announcement.connect(func(t): _add("[ОБЪЯВЛЕНИЕ] " + t, Color("ffd24a")))
    NetworkManager.roster_changed.connect(func(): visible = NetworkManager.is_online)
    visible = false


func _send():
    NetworkManager.send_chat(input.text)
    input.text = ""


func _on_chat(nick, text, admin):
    _add("%s%s: %s" % ["[АДМИН] " if admin else "", nick, text], Color("ffe9a0") if admin else Color.WHITE)


func _add(text, color):
    var l = UIF.label(text, 19, color, true)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    l.custom_minimum_size = Vector2(430, 0)
    log_box.add_child(l)
    while log_box.get_child_count() > 6:
        var old = log_box.get_child(0)
        log_box.remove_child(old)
        old.queue_free()
    var tw = l.create_tween()
    tw.tween_interval(14.0)
    tw.tween_property(l, "modulate:a", 0.0, 1.0)
