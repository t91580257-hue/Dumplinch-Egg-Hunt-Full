extends Control
## HUD: здоровье, опыт, валюты, мини-карта, задание, кнопки окон, уведомления, босс-бар.

const UIF = preload("res://scripts/ui/ui_factory.gd")
const Icon = preload("res://scripts/ui/icon.gd")
const MiniMap = preload("res://scripts/ui/minimap.gd")
const TouchControls = preload("res://scripts/ui/touch_controls.gd")
const MainMenu = preload("res://scripts/ui/main_menu.gd")
const InventoryWindow = preload("res://scripts/ui/inventory_window.gd")
const PetsWindow = preload("res://scripts/ui/pets_window.gd")
const ShopWindow = preload("res://scripts/ui/shop_window.gd")
const MapWindow = preload("res://scripts/ui/map_window.gd")
const QuestsWindow = preload("res://scripts/ui/quests_window.gd")
const CodexWindow = preload("res://scripts/ui/codex_window.gd")
const SettingsWindow = preload("res://scripts/ui/settings_window.gd")
const RevealWindow = preload("res://scripts/ui/reveal_window.gd")
const RewardWindow = preload("res://scripts/ui/reward_window.gd")

signal menu_play(new_game)

var game_layer
var hp_bar
var hp_label
var xp_bar
var lvl_label
var quest_label
var cur_labels = {}
var boss_panel
var boss_name
var boss_bar
var banner
var toast_box
var flash_rect
var prompt_label
var reveal_label
var buttons_row
var minimap
var windows = {}
var reveal_window
var reward_window
var combo_label
var menu
var _rect_t = 0.0
var top_right
var _vp = Vector2.ZERO


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    theme = UIF.make_theme()
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer = Control.new()
    game_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(game_layer)
    game_layer.add_child(TouchControls.new())
    _build_status()
    _build_top_right()
    _build_center()
    flash_rect = ColorRect.new()
    flash_rect.color = Color(1, 1, 1, 0)
    flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer.add_child(flash_rect)
    windows = {"inv": InventoryWindow.new(), "pets": PetsWindow.new(), "shop": ShopWindow.new(), "map": MapWindow.new(),
        "quests": QuestsWindow.new(), "codex": CodexWindow.new(), "settings": SettingsWindow.new()}
    for k in windows:
        add_child(windows[k])
    reveal_window = RevealWindow.new()
    add_child(reveal_window)
    reward_window = RewardWindow.new()
    add_child(reward_window)
    menu = MainMenu.new()
    menu.play_pressed.connect(func(n): menu_play.emit(n))
    add_child(menu)
    GameState.currency_changed.connect(refresh)
    GameState.stats_changed.connect(refresh)
    GameState.message.connect(toast)
    GameState.quest_completed.connect(_on_quest_done)
    GameState.boss_bar.connect(_on_boss_bar)
    GameState.region_changed.connect(_on_region)
    GameState.screen_flash.connect(_on_flash)
    GameState.prompt_changed.connect(_on_prompt)
    GameState.player_died.connect(_on_died)
    GameState.reveal_pet.connect(_on_reveal)
    GameState.victory.connect(_on_victory)
    GameState.reveal_reward.connect(_on_reward)
    GameState.combo_changed.connect(_on_combo)
    refresh()
    _layout()


func set_in_menu(b):
    menu.visible = b
    game_layer.visible = not b
    if b:
        for k in windows:
            windows[k].close()
        reveal_window.close()
        reward_window.close()


func _build_status():
    var p = PanelContainer.new()
    p.position = Vector2(12, 10)
    game_layer.add_child(p)
    var v = VBoxContainer.new()
    v.add_theme_constant_override("separation", 4)
    p.add_child(v)
    var r = UIF.row(v)
    r.add_child(Icon.new("heart", 30))
    hp_bar = UIF.bar(Color("e8485a"), 28, 250)
    r.add_child(hp_bar)
    hp_label = UIF.label("100/100", 18)
    hp_label.set_anchors_preset(Control.PRESET_FULL_RECT)
    hp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hp_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    hp_bar.add_child(hp_label)
    lvl_label = UIF.label("Ур. 1", 22, Color("ffd24a"))
    v.add_child(lvl_label)
    xp_bar = UIF.bar(Color("4aa8ff"), 14, 280)
    v.add_child(xp_bar)
    quest_label = UIF.label("", 17, Color(0.85, 0.92, 1.0), true)
    quest_label.custom_minimum_size = Vector2(280, 0)
    v.add_child(quest_label)


func _icon_btn(kind, win):
    var b = UIF.icon_button(kind, 68)
    b.pressed.connect(open_window.bind(win))
    buttons_row.add_child(b)


func _build_top_right():
    var v = VBoxContainer.new()
    v.add_theme_constant_override("separation", 6)
    v.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top_right = v
    game_layer.add_child(v)
    var cp = PanelContainer.new()
    cp.size_flags_horizontal = Control.SIZE_SHRINK_END
    v.add_child(cp)
    var ch = HBoxContainer.new()
    ch.add_theme_constant_override("separation", 10)
    cp.add_child(ch)
    for c in ["coins", "gems", "crystals", "tokens"]:
        ch.add_child(Icon.new(UIF.CUR_ICONS[c], 28))
        var l = UIF.label("0", 22, Color("ffe9a0"))
        l.custom_minimum_size = Vector2(60, 0)
        ch.add_child(l)
        cur_labels[c] = l
    buttons_row = HBoxContainer.new()
    buttons_row.add_theme_constant_override("separation", 6)
    buttons_row.alignment = BoxContainer.ALIGNMENT_END
    v.add_child(buttons_row)
    _icon_btn("bag", "inv")
    _icon_btn("paw", "pets")
    _icon_btn("shop", "shop")
    _icon_btn("map", "map")
    _icon_btn("scroll", "quests")
    _icon_btn("trophy", "codex")
    _icon_btn("gear", "settings")
    minimap = MiniMap.new(false)
    minimap.size_flags_horizontal = Control.SIZE_SHRINK_END
    minimap.custom_minimum_size = Vector2(190, 190)
    v.add_child(minimap)


func _build_center():
    banner = UIF.label("", 56, Color.WHITE)
    banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    banner.add_theme_constant_override("outline_size", 12)
    banner.modulate.a = 0.0
    banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer.add_child(banner)
    toast_box = VBoxContainer.new()
    toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer.add_child(toast_box)
    boss_panel = PanelContainer.new()
    boss_panel.visible = false
    game_layer.add_child(boss_panel)
    var bv = VBoxContainer.new()
    boss_panel.add_child(bv)
    boss_name = UIF.label("", 24, Color("ff9ed0"))
    boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    bv.add_child(boss_name)
    boss_bar = UIF.bar(Color("c030ff"), 24, 300)
    boss_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    bv.add_child(boss_bar)
    prompt_label = UIF.label("", 24, Color("9fffa0"))
    prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    prompt_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer.add_child(prompt_label)
    reveal_label = UIF.label("", 44, Color.WHITE)
    reveal_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    reveal_label.add_theme_constant_override("outline_size", 12)
    reveal_label.modulate.a = 0.0
    reveal_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer.add_child(reveal_label)
    combo_label = UIF.label("", 46, Color.WHITE)
    combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    combo_label.add_theme_constant_override("outline_size", 12)
    combo_label.modulate.a = 0.0
    combo_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    game_layer.add_child(combo_label)


func open_window(key):
    if GameState.cinematic_busy or GameState.in_menu:
        return
    for k in windows:
        if k != key:
            windows[k].close()
    windows[key].open()


func close_all():
    for k in windows:
        windows[k].close()
    reveal_window.close()
    reward_window.close()


func refresh():
    if hp_bar == null:
        return
    for c in cur_labels:
        cur_labels[c].text = str(GameState.get_cur(c))
    var mh = GameState.max_hp()
    hp_bar.max_value = mh
    hp_bar.value = maxf(GameState.hp, 0.0)
    hp_label.text = "%d/%d" % [int(maxf(GameState.hp, 0.0)), int(mh)]
    xp_bar.max_value = GameState.xp_needed()
    xp_bar.value = GameState.xp
    lvl_label.text = "Ур. %d  -  %s" % [GameState.level, GameState.current_title()]
    var q = GameState.active_story()
    if q != null:
        quest_label.text = "Задание: %s (%d/%d)" % [q.title, mini(GameState.stat_value(q.key), int(q.target)), int(q.target)]
    else:
        quest_label.text = "Все сюжетные задания выполнены"


func _layout():
    # Вёрстка без якорей: всё считается от размера экрана.
    _vp = get_viewport_rect().size
    var vp = _vp
    position = Vector2.ZERO
    size = vp
    game_layer.position = Vector2.ZERO
    game_layer.size = vp
    flash_rect.position = Vector2.ZERO
    flash_rect.size = vp
    top_right.size = Vector2(700, 0)
    top_right.position = Vector2(vp.x - 712, 10)
    banner.position = Vector2(0, 150)
    banner.size = Vector2(vp.x, 80)
    toast_box.position = Vector2(vp.x * 0.25, 90)
    toast_box.size = Vector2(vp.x * 0.5, 10)
    boss_panel.position = Vector2(vp.x * 0.25, 8)
    boss_panel.size = Vector2(vp.x * 0.5, 10)
    prompt_label.position = Vector2(0, vp.y * 0.62)
    prompt_label.size = Vector2(vp.x, 40)
    reveal_label.position = Vector2(0, vp.y * 0.66)
    reveal_label.size = Vector2(vp.x, 120)
    combo_label.position = Vector2(vp.x - 520, 350)
    combo_label.size = Vector2(500, 70)
    combo_label.pivot_offset = Vector2(500, 35)
    GameState.ui_rects = [Rect2(vp.x - 712, 0, 712, 340), Rect2(0, 0, 330, 260)]


func _process(delta):
    if get_viewport_rect().size != _vp:
        _layout()
    if GameState.combo > 1:
        combo_label.modulate.a = clampf(GameState.combo_t / 0.7, 0.35, 1.0)


func toast(text):
    if toast_box == null:
        return
    var l = UIF.label(text, 24, Color("fff2b0"))
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    toast_box.add_child(l)
    while toast_box.get_child_count() > 4:
        toast_box.get_child(0).queue_free()
        toast_box.remove_child(toast_box.get_child(0))
    var tw = l.create_tween()
    tw.tween_interval(2.6)
    tw.tween_property(l, "modulate:a", 0.0, 0.6)
    tw.tween_callback(l.queue_free)


func show_banner(text, color = Color.WHITE, dur = 2.2):
    banner.text = text
    banner.add_theme_color_override("font_color", color)
    var tw = create_tween()
    tw.tween_property(banner, "modulate:a", 1.0, 0.3)
    tw.tween_interval(dur)
    tw.tween_property(banner, "modulate:a", 0.0, 0.6)


func _on_quest_done(title):
    toast("Задание выполнено: " + title)
    AudioManager.play_ui("reward")


func _on_boss_bar(bname, hp, max_hp, shown):
    boss_panel.visible = shown
    if shown:
        boss_name.text = bname
        boss_bar.max_value = max_hp
        boss_bar.value = maxf(hp, 0.0)


func _on_region(i):
    var rd = GameData.REGIONS[i]
    show_banner(rd.name, rd.sky_hor.lightened(0.2))


func _on_flash(color, dur):
    flash_rect.color = Color(color.r, color.g, color.b, color.a)
    var tw = create_tween()
    tw.tween_property(flash_rect, "color:a", 0.0, dur)


func _on_prompt(text):
    prompt_label.text = text


func _on_died():
    show_banner("Поражение", Color("ff5a5a"), 1.8)


func _on_victory():
    show_banner("ПОБЕДА! Вы - Король Яиц!", Color("ffd24a"), 6.0)


func _on_reveal(pet):
    var d = GameData.pet(pet.id)
    reveal_label.text = "%s\n%s" % [d.name, GameData.rarity_name(d.rarity)]
    reveal_label.add_theme_color_override("font_color", GameData.rarity_color(d.rarity).lightened(0.3))
    var tw = create_tween()
    tw.tween_property(reveal_label, "modulate:a", 1.0, 0.25)
    tw.tween_interval(2.3)
    tw.tween_property(reveal_label, "modulate:a", 0.0, 0.5)


func _on_reward(res):
    reward_window.show_rewards(res)
    if res.unique != null:
        show_banner("Уникальное яйцо: " + res.unique.name, GameData.rarity_color(res.best).lightened(0.3), 3.5)


func _on_combo(n):
    if n <= 1:
        combo_label.modulate.a = 0.0
        return
    combo_label.text = "КОМБО x%d" % n
    var col = GameState.combo_color()
    combo_label.add_theme_color_override("font_color", col)
    combo_label.modulate.a = 1.0
    var k = 1.25 + minf(0.4, n * 0.01)
    combo_label.scale = Vector2(k, k)
    create_tween().tween_property(combo_label, "scale", Vector2.ONE, 0.2)
    if n == 5 or n == 10 or n == 20 or n == 30 or n == 50:
        toast("Комбо x%d!" % n)
        AudioManager.play_ui("reward")
