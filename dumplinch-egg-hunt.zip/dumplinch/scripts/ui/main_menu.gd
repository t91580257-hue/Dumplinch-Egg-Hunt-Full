extends Control
## Главное меню поверх 3D-мира (камера медленно облетает локацию).

const UIF = preload("res://scripts/ui/ui_factory.gd")
signal play_pressed(new_game)
signal online_pressed
signal logout_pressed
var cont
var acc_label
var _confirm = false
var _box
var _new_btn
var dim
var center
var _vp = Vector2.ZERO


func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    dim = ColorRect.new()
    dim.color = Color(0.03, 0.05, 0.12, 0.45)
    add_child(dim)
    center = CenterContainer.new()
    add_child(center)
    _box = VBoxContainer.new()
    _box.add_theme_constant_override("separation", 14)
    center.add_child(_box)
    var title = UIF.label("DUMPLINCH", 84, Color("ffd24a"))
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_constant_override("outline_size", 14)
    _box.add_child(title)
    var sub = UIF.label("EGG HUNT", 52, Color("ff9ed0"))
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    sub.add_theme_constant_override("outline_size", 10)
    _box.add_child(sub)
    acc_label = UIF.label("", 22, Color(0.85, 0.92, 1.0))
    acc_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _box.add_child(acc_label)
    cont = UIF.button("Продолжить", Vector2(420, 72), 28)
    cont.pressed.connect(func(): play_pressed.emit(false))
    _box.add_child(cont)
    _new_btn = UIF.button("Новая игра", Vector2(420, 72), 28)
    _new_btn.pressed.connect(_on_new)
    _box.add_child(_new_btn)
    var onl = UIF.button("Онлайн", Vector2(420, 64), 24)
    onl.pressed.connect(func(): online_pressed.emit())
    _box.add_child(onl)
    var lo = UIF.button("Сменить аккаунт", Vector2(420, 56), 22)
    lo.pressed.connect(func(): logout_pressed.emit())
    _box.add_child(lo)
    var q = UIF.button("Выход", Vector2(420, 64), 24)
    q.pressed.connect(func(): get_tree().quit())
    _box.add_child(q)
    var ver = UIF.label("Версия 0.3.0 - ранний прототип", 18, Color(0.8, 0.85, 1.0))
    ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _box.add_child(ver)
    modulate.a = 0.0
    create_tween().tween_property(self, "modulate:a", 1.0, 0.8)
    _fit()


func _fit():
    _vp = get_viewport_rect().size
    position = Vector2.ZERO
    size = _vp
    dim.position = Vector2.ZERO
    dim.size = _vp
    center.position = Vector2.ZERO
    center.size = _vp


func _process(_d):
    if get_viewport_rect().size != _vp:
        _fit()


func refresh():
    _confirm = false
    _new_btn.text = "Новая игра"
    cont.disabled = not SaveSystem.has_save()
    var tag = "  [АДМИН]" if AccountSystem.is_admin else ""
    acc_label.text = "Аккаунт: %s%s" % [AccountSystem.current_nick, tag]


func _on_new():
    if SaveSystem.has_save() and not _confirm:
        _confirm = true
        _new_btn.text = "Точно удалить прогресс? Нажмите ещё раз"
        return
    play_pressed.emit(true)
