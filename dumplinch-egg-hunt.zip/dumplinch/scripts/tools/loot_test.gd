extends SceneTree
## Проверка шансов и правил сундуков без запуска игры:
##   godot --headless --path . --script res://scripts/tools/loot_test.gd
## Проверяет: уникальные яйца есть ТОЛЬКО в сундуках; симулирует открытие сундуков; вылупление; цикл сохранения.

var errors = 0


func _fail(msg):
    errors += 1
    print("ОШИБКА: ", msg)


func _initialize():
    var gs = root.get_node("GameState")
    var gd = root.get_node("GameData")
    print("Уникальных яиц: %d, питомцев всего: %d" % [gd.UNIQUE_EGGS.size(), gd.PETS.size()])
    if gd.UNIQUE_EGGS.size() < 15:
        _fail("уникальных яиц меньше 15")
    if gd.PETS.size() < 60:
        _fail("питомцев меньше 60 (30 старых + 30 новых)")
    # 1. уникальные яйца не должны встречаться ни в одном обычном источнике
    for e in gd.UNIQUE_EGGS:
        for x in gd.EGGS:
            if x.id == e.id:
                _fail("id совпадает с обычным яйцом: " + e.id)
        for r in gd.REGIONS:
            if r.eggs.has(e.id):
                _fail("уникальное яйцо в мире региона: " + e.id)
        for b in gd.BOSSES:
            if b.egg == e.id:
                _fail("уникальное яйцо в награде босса: " + e.id)
        for q in gd.STORY + gd.SIDE + gd.SECRET + gd.ACHIEVEMENTS:
            if q.reward.get("egg", "") == e.id:
                _fail("уникальное яйцо в награде задания: " + e.id)
        for t in gd.DAILY_TEMPLATES:
            if t.reward.get("egg", "") == e.id:
                _fail("уникальное яйцо в ежедневной награде: " + e.id)
        for c in gd.CHESTS:
            if gd.CHESTS[c].egg_pool.has(e.id):
                _fail("уникальное яйцо в обычном пуле сундука: " + e.id)
        if gd.pets_of_egg(e.id).size() < 2:
            _fail("у яйца меньше двух питомцев: " + e.id)
    # 2. симуляция открытия сундуков
    for ctype in gd.CHEST_ORDER:
        gs.new_game()
        gs.current_region = 0
        var n = 5000
        gs.chests[ctype] = n
        var cd = gd.CHESTS[ctype]
        var got = 0
        var sp = 0
        for i in n:
            var res = gs.open_chest(ctype)
            if res == null:
                _fail("open_chest вернул null: " + ctype)
                break
            if res.special != null:
                sp += 1
                if ctype != "secret":
                    _fail("особое яйцо выпало не из секретного сундука: " + ctype)
            if res.unique != null:
                got += 1
                if res.unique.tier < cd.unique[1] or res.unique.tier > cd.unique[2]:
                    _fail("яйцо вне диапазона сундука %s: %s" % [ctype, res.unique.id])
        if gs.chests.get(ctype, 0) != 0:
            _fail("после %d открытий в инвентаре осталось %d" % [n, gs.chests.get(ctype, 0)])
        if ctype == "secret":
            var rate = 100.0 * sp / n
            print("секретный: плюшевое яйцо %.2f%% (ожидается 10%%)" % rate)
            if rate < 8.0 or rate > 12.0:
                _fail("шанс плюшевого яйца вне 8-12%%: %.2f" % rate)
        print("%-10s уникальных яиц: %5.2f%% (базовый шанс %.1f%%, с гарантией чаще)" % [ctype, 100.0 * got / n, cd.unique[0] * 100.0])
    # Химик и Милик: по 400 силы, только из плюшевого яйца
    gs.new_game()
    for id in ["pet_plush_himik", "pet_plush_milik"]:
        var pp = gs.add_pet(id)
        if int(gs.pet_power(pp)) != 400:
            _fail("сила %s не равна 400: %d" % [id, int(gs.pet_power(pp))])
        if gd.pet(id).egg != "plush":
            _fail("питомец не из плюшевого яйца: " + id)
    # повторное открытие при нуле сундуков не должно давать награду
    gs.new_game()
    if gs.open_chest("common") != null:
        _fail("открытие несуществующего сундука дало награду")
    # 3. вылупление питомцев из уникальных яиц
    for e in gd.UNIQUE_EGGS:
        gs.new_game()
        gs.add_egg(e.id, 200)
        var seen = {}
        for i in 200:
            var p = gs.open_egg(e.id)
            if p == null:
                _fail("не открылось яйцо " + e.id)
                break
            if gd.pet(p.id).egg != e.id:
                _fail("питомец не из этого яйца: " + e.id)
            seen[p.id] = true
        if seen.size() < 2:
            print("  предупреждение: из %s за 200 попыток выпал только один питомец (второй очень редкий)" % e.id)
    # 4. цикл сохранения: JSON туда-обратно
    gs.new_game()
    gs.add_chest("magic", 3)
    gs.add_egg("infinity", 1)
    gs.discovered_eggs.append("infinity")
    gs.chest_respawn["w0_1"] = 12345.0
    var data = JSON.parse_string(JSON.stringify(gs.to_dict()))
    gs.from_dict(data)
    if gs.chests.get("magic", 0) != 3 or gs.eggs.get("infinity", 0) != 1 or not gs.discovered_eggs.has("infinity") or gs.chest_respawn.get("w0_1", 0.0) != 12345.0:
        _fail("сохранение сундуков или яиц потеряло данные")
    # 5. старое сохранение (без полей сундуков) загружается
    var old = {"level": 7, "coins": 999, "pets": [], "eggs": {"common": 2}}
    gs.from_dict(old)
    if gs.level != 7 or gs.coins != 999 or not gs.chests.is_empty():
        _fail("старое сохранение загрузилось неверно")
    print("Ошибок: ", errors)
    quit(1 if errors > 0 else 0)
