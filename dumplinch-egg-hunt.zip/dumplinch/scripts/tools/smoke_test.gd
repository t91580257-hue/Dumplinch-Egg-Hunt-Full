extends SceneTree
## Дымовой тест: godot --headless --path . --script res://scripts/tools/smoke_test.gd
## Регистрирует тестовый аккаунт и администратора, запускает главную сцену ~400 кадров, открывает яйцо и админ-окно.

var frames = 0
var main


func _initialize():
    var acc = root.get_node("AccountSystem")
    # ник DUMPLINCH нельзя занять с чужим паролем
    var bad = acc.register("DUMPLINCH", "bad_try", "wrongpass1", "wrongpass1")
    if bad == "":
        print("SCRIPT ERROR: ник DUMPLINCH занят без пароля администратора")
    var err = acc.register("DUMPLINCH", "admin_smoke", "DUMPLINCH1", "DUMPLINCH1")
    if err != "" or not acc.is_admin:
        print("SCRIPT ERROR: вход администратора не удался: ", err)
    main = load("res://scenes/main.tscn").instantiate()
    root.add_child(main)


func _process(_delta):
    frames += 1
    var gs = root.get_node("GameState")
    if frames == 20:
        gs.in_menu = false
        main.hud.set_in_menu(false)
        gs.grant_gifts()
    if frames == 60:
        gs.request_open_egg.emit("common", 1)
    if frames == 200:
        var w = main.hud.windows["admin"]
        w.open()
        print("ADMIN cmd: ", w.run_command("give coins 10"), " ", w.run_command("region 2"))
        w.close()
    if frames == 400:
        print("SMOKE_OK pets=", gs.pets.size(), " admin=", root.get_node("AccountSystem").is_admin)
        quit(0)
    return false
